=== Farsi Learning Manager ===
Contributors: JH Photographers  
Tags: education, learning, lessons, farsi, submissions
Requires at least: 5.0
Tested up to: 6.4
Stable tag: 2.3.0
License: GPLv2 or later

Collaborative Farsi lesson management with complete frontend management system.

== Description ==

**v2.3.0 - COMPLETE FRONTEND MANAGEMENT!**

NEW FEATURES:
✅ Instructor Upload Form - Create lessons from frontend (no wp-admin needed!)
✅ My Lessons Dashboard - Manage your own lessons with inline editing
✅ User Profile Page - Update email and password from frontend
✅ Title Editing - Edit lesson titles directly in the list
✅ Files Modal - Bulk edit all 3 files (student, teacher, audio) at once

EXISTING FEATURES:
✅ Real-time search functionality
✅ Security code system for submissions
✅ Email notifications
✅ Permission-based access control
✅ Custom user roles (Team Leader, Chairperson, Instructor)

== Shortcodes ==

1. [farsi_instructor_form] - Frontend lesson creation form
2. [farsi_my_lessons] - Personal lessons dashboard with editing
3. [farsi_lesson_list] - All lessons list (searchable)
4. [farsi_profile] - User profile management
5. [farsi_student_form] - Student submission form

== Installation ==

1. Upload plugin via WordPress admin
2. Activate the plugin
3. Create 5 pages with the shortcodes above
4. Configure security codes in admin
5. Add users with appropriate roles

== Changelog ==

= 2.3.0 =
* NEW: Instructor upload form shortcode [farsi_instructor_form]
* NEW: My Lessons dashboard with inline editing [farsi_my_lessons]
* NEW: User profile page [farsi_profile]
* NEW: Title editing in lesson lists
* NEW: Files modal for bulk file editing
* IMPROVED: Updated settings page with all 5 shortcodes
* IMPROVED: Better permission checks
* IMPROVED: Mobile responsive design

= 2.2.0 =
* Added real-time search functionality
* Search by title or notes
* Live results counter

= 2.1.0 =
* Fixed notes editing
* Improved CSS loading
* Design consistency improvements

= 2.0.0 =
* Initial release
