/**
 * Frontend Scripts - Farsi Learning Manager
 * FIXED: Notes editing now works properly
 */

jQuery(function($) {
    
    /* ==========================================================================
       LESSON LIST SEARCH
       ========================================================================== */
    
    // Only run if search field exists
    if ($('#flm-lesson-search').length > 0) {
        const $searchInput = $('#flm-lesson-search');
        const $searchClear = $('#flm-search-clear');
        const $searchResults = $('#flm-search-results');
        const $lessonRows = $('.flm-list tbody tr');
        const totalLessons = $lessonRows.length;
        
        // Real-time search
        $searchInput.on('input', function() {
            const searchTerm = $(this).val().toLowerCase().trim();
            
            if (searchTerm.length > 0) {
                $searchClear.show();
                
                let visibleCount = 0;
                
                $lessonRows.each(function() {
                    const $row = $(this);
                    const title = $row.data('search-title') || '';
                    const instructor = $row.data('search-instructor') || '';
                    const notes = $row.data('search-notes') || '';
                    
                    const searchText = title + ' ' + instructor + ' ' + notes;
                    
                    if (searchText.includes(searchTerm)) {
                        $row.show();
                        visibleCount++;
                    } else {
                        $row.hide();
                    }
                });
                
                // Update results counter
                $searchResults.text('Found ' + visibleCount + ' lesson(s)');
                
                // Show "no results" message if needed
                if (visibleCount === 0) {
                    if ($('.flm-no-results').length === 0) {
                        $('.flm-list').after('<div class="flm-no-results"><i class="fas fa-search"></i>No lessons found matching your search.</div>');
                    }
                } else {
                    $('.flm-no-results').remove();
                }
                
            } else {
                clearSearch();
            }
        });
        
        // Clear button
        $searchClear.on('click', function() {
            clearSearch();
            $searchInput.focus();
        });
        
        // ESC key to clear
        $searchInput.on('keydown', function(e) {
            if (e.key === 'Escape') {
                clearSearch();
            }
        });
        
        // Clear search function
        function clearSearch() {
            $searchInput.val('');
            $searchClear.hide();
            $lessonRows.show();
            $searchResults.text('Found ' + totalLessons + ' lesson(s)');
            $('.flm-no-results').remove();
        }
    }
    
    /* ==========================================================================
       SUBMISSION FORM - Multi-file upload
       ========================================================================== */
    
    let uploadCount = 1;
    
    // Real-time security code validation
    let codeCheckTimeout;
    const $securityCode = $('#flm-security-code');
    const $codeStatus = $('#flm-code-status');
    const $codeNote = $('#flm-code-note');
    const $submitBtn = $('#flm-submit');
    
    if ($securityCode.length > 0) {
        // Check code as user types (with debounce)
        $securityCode.on('input', function() {
            const code = $(this).val().trim();
            
            // Clear previous timeout
            clearTimeout(codeCheckTimeout);
            
            // Reset status
            $codeStatus.removeClass('checking valid invalid').hide();
            $codeNote.removeClass('valid invalid').text('Contact your administrator for the security code');
            $submitBtn.prop('disabled', true);
            
            if (code.length === 0) {
                return;
            }
            
            // Show checking status
            $codeStatus.removeClass('valid invalid').addClass('checking').html('<i class="fas fa-spinner fa-spin"></i>').show();
            
            // Wait 500ms after user stops typing
            codeCheckTimeout = setTimeout(function() {
                $.ajax({
                    url: flmFrontend.ajaxurl,
                    type: 'POST',
                    data: {
                        action: 'flm_validate_security_code',
                        code: code
                    },
                    success: function(res) {
                        if (res.success) {
                            // Valid code
                            $codeStatus.removeClass('checking invalid').addClass('valid').html('<i class="fas fa-check-circle"></i>');
                            $codeNote.removeClass('invalid').addClass('valid').text('✓ Valid security code');
                            $submitBtn.prop('disabled', false);
                        } else {
                            // Invalid code
                            $codeStatus.removeClass('checking valid').addClass('invalid').html('<i class="fas fa-times-circle"></i>');
                            $codeNote.removeClass('valid').addClass('invalid').text('✗ Invalid security code');
                            $submitBtn.prop('disabled', true);
                        }
                    },
                    error: function() {
                        $codeStatus.removeClass('checking valid').addClass('invalid').html('<i class="fas fa-times-circle"></i>');
                        $codeNote.removeClass('valid').addClass('invalid').text('Error checking code. Please try again.');
                        $submitBtn.prop('disabled', true);
                    }
                });
            }, 500);
        });
    }
    
    // Add more file inputs
    $('#flm-add-file').on('click', function(e) {
        e.preventDefault();
        uploadCount++;
        const fileHtml = `
            <div class="flm-upload-row" data-upload="${uploadCount}">
                <input type="file" name="submission_files[]" accept=".pdf,.doc,.docx" required>
                <button type="button" class="flm-remove-file" data-upload="${uploadCount}">
                    <i class="fas fa-times"></i> Remove
                </button>
            </div>
        `;
        $('#flm-uploads-container').append(fileHtml);
    });
    
    // Remove file input
    $(document).on('click', '.flm-remove-file', function() {
        const uploadId = $(this).data('upload');
        $(`.flm-upload-row[data-upload="${uploadId}"]`).remove();
    });
    
    // Form submission
    $('#flm-form').on('submit', function(e) {
        e.preventDefault();
        
        var $btn = $('#flm-submit');
        var $msg = $('#flm-message');
        
        $btn.prop('disabled', true).text('Submitting...');
        $msg.hide();
        
        var formData = new FormData(this);
        
        $.ajax({
            url: flmFrontend.ajaxurl,
            type: 'POST',
            data: formData,
            processData: false,
            contentType: false,
            success: function(res) {
                if (res.success) {
                    $msg.removeClass('error').addClass('success').html(res.data.message).show();
                    $('#flm-form')[0].reset();
                    $('.flm-upload-row').not(':first').remove();
                    uploadCount = 1;
                } else {
                    $msg.removeClass('success').addClass('error').html(res.data.message).show();
                }
            },
            error: function() {
                $msg.removeClass('success').addClass('error').html('An error occurred. Please try again.').show();
            },
            complete: function() {
                $btn.prop('disabled', false).text('Submit');
            }
        });
    });
    
    /* ==========================================================================
       LESSON LIST - NOTES EDITING (FIXED!)
       ========================================================================== */
    
    // Edit notes button - ONLY works if data-can-edit="true"
    $(document).on('click', '.flm-btn-edit-note[data-can-edit="true"]', function(e) {
        e.preventDefault();
        console.log('Edit button clicked');
        
        var $btn = $(this);
        var $row = $btn.closest('tr');
        var $display = $row.find('.flm-notes-display');
        var $edit = $row.find('.flm-notes-edit');
        
        $display.hide();
        $edit.show();
        $row.find('.flm-notes-textarea').focus();
    });
    
    // Cancel button
    $(document).on('click', '.flm-btn-cancel-note', function(e) {
        e.preventDefault();
        var $btn = $(this);
        var $row = $btn.closest('tr');
        var $display = $row.find('.flm-notes-display');
        var $edit = $row.find('.flm-notes-edit');
        
        $edit.hide();
        $display.show();
    });
    
    // Save notes button
    $(document).on('click', '.flm-btn-save-note', function(e) {
        e.preventDefault();
        var $btn = $(this);
        var $row = $btn.closest('tr');
        var lessonId = $btn.data('lesson-id');
        var notes = $row.find('.flm-notes-textarea').val();
        
        console.log('Saving notes for lesson:', lessonId);
        
        var originalText = $btn.text();
        $btn.prop('disabled', true).text('Saving...');
        
        $.ajax({
            url: flmFrontend.ajaxurl,
            type: 'POST',
            data: {
                action: 'flm_save_notes',
                nonce: flmFrontend.nonce,
                lesson_id: lessonId,
                notes: notes
            },
            success: function(res) {
                console.log('AJAX response:', res);
                if (res.success) {
                    var displayText = notes ? notes : '<em style="color:#999;">No notes</em>';
                    $row.find('.flm-notes-content').html(displayText);
                    $row.find('.flm-notes-edit').hide();
                    $row.find('.flm-notes-display').show();
                } else {
                    alert('Failed to save notes: ' + (res.data.message || 'Unknown error'));
                }
            },
            error: function(xhr, status, error) {
                console.error('AJAX error:', error);
                alert('An error occurred while saving notes.');
            },
            complete: function() {
                $btn.prop('disabled', false).text(originalText);
            }
        });
    });
    
    /* ==========================================================================
       LESSON DELETE
       ========================================================================== */
    
    $(document).on('click', '.flm-btn-delete:not(.disabled)', function(e) {
        e.preventDefault();
        
        if (!confirm('Are you sure you want to delete this lesson permanently? This cannot be undone.')) {
            return;
        }
        
        var $btn = $(this);
        var lessonId = $btn.data('lesson-id');
        var nonce = $('#flm_delete_nonce').val();
        var $row = $btn.closest('tr');
        
        $btn.prop('disabled', true).html('<i class="fas fa-spinner fa-spin"></i>');
        
        $.ajax({
            url: flmFrontend.ajaxurl,
            type: 'POST',
            data: {
                action: 'flm_delete_lesson',
                nonce: nonce,
                lesson_id: lessonId
            },
            success: function(res) {
                if (res.success) {
                    $row.fadeOut(300, function() { $(this).remove(); });
                } else {
                    alert('Error: ' + res.data.message);
                    $btn.prop('disabled', false).html('<i class="fas fa-trash"></i>');
                }
            },
            error: function() {
                alert('An error occurred while deleting the lesson.');
                $btn.prop('disabled', false).html('<i class="fas fa-trash"></i>');
            }
        });
    });
    
    /* ==========================================================================
       COPY LINK BUTTONS
       ========================================================================== */
    
    $(document).on('click', '.flm-copy-link', function(e) {
        e.preventDefault();
        var $btn = $(this);
        var url = $btn.data('url');
        
        var $temp = $('<input>');
        $('body').append($temp);
        $temp.val(url).select();
        document.execCommand('copy');
        $temp.remove();
        
        var originalText = $btn.text();
        $btn.addClass('copied').text('Copied!');
        
        setTimeout(function() {
            $btn.removeClass('copied').text(originalText);
        }, 2000);
    });
    
    console.log('FLM Frontend Scripts Loaded');
    console.log('flmFrontend object:', flmFrontend);
    
});
