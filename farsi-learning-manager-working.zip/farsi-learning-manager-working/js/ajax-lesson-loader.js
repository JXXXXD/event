/**
 * AJAX Lesson List - Always Fresh, No Cache Issues!
 * This loads lessons via AJAX so they're ALWAYS current
 */

jQuery(function($) {
    
    /* ==========================================================================
       AJAX LESSON LIST LOADER - Bypasses ALL Cache!
       ========================================================================== */
    
    // Check if we're on a page with lesson list
    if ($('.flm-list-wrapper').length > 0) {
        
        console.log('🔄 FLM: Loading fresh lesson data via AJAX...');
        
        // Show loading state
        var $wrapper = $('.flm-list-wrapper');
        var $tbody = $('.flm-list tbody');
        var $searchResults = $('.flm-search-results');
        
        // Get list type from the wrapper element to send to the AJAX handler
        var listType = $wrapper.data('list-type') || 'all-lessons';
        
        // Add loading indicator
        $tbody.html('<tr><td colspan="10" style="text-align:center;padding:40px;"><i class="fas fa-spinner fa-spin" style="font-size:24px;margin-right:10px;"></i> Loading lessons...</td></tr>');
        
        // Fetch fresh lessons from database
        $.ajax({
            url: flmFrontend.ajaxurl,
            type: 'POST',
            data: {
                action: 'flm_get_fresh_lessons',
                nonce: flmFrontend.nonce,
                list_type: listType // Pass the list type for accurate querying
            },
            success: function(response) {
                if (response.success) {
                    
                    console.log('✅ FLM: Loaded ' + response.data.count + ' lessons from database');
                    
                    // Handle No Lessons Message when the count is 0
                    if (response.data.count === 0) {
                         var noLessonsMsg;
                         if (listType === 'my-lessons') {
                            noLessonsMsg = '<tr><td colspan="10" style="text-align:center;padding:40px;color:#999;">You haven\'t created any lessons yet.</td></tr>';
                         } else {
                            noLessonsMsg = '<tr><td colspan="10" style="text-align:center;padding:40px;color:#999;">No lessons available.</td></tr>';
                         }
                        $tbody.html(noLessonsMsg);
                    } else {
                        // Replace table body with fresh HTML
                        $tbody.html(response.data.html);
                    }
                    
                    // Update search results count
                    $searchResults.html('Found ' + response.data.count + ' lesson(s)');
                    
                    // Re-initialize all event handlers for the new content
                    flm_reinitialize_handlers();
                    
                } else {
                    // NEW: Improved error reporting on list load failure
                    const errorMsg = response.data && response.data.message ? response.data.message : 'Unknown server error.';
                    $tbody.html('<tr><td colspan="10" style="text-align:center;padding:40px;color:#dc3545;">Error loading lessons: ' + errorMsg + '</td></tr>');
                }
            },
            error: function(xhr, status, error) {
                // NEW: Generic network error reporting with status
                $tbody.html('<tr><td colspan="10" style="text-align:center;padding:40px;color:#dc3545;">Network Error (Code: ' + status + '). Please refresh the page.</td></tr>');
            }
        });
    }
    
    // Re-initialize all event handlers after AJAX load
    function flm_reinitialize_handlers() {
        
        // Search functionality
        const $searchInput = $('#flm-lesson-search');
        const $searchClear = $('#flm-search-clear');
        const $searchResults = $('#flm-search-results');
        const $lessonRows = $('.flm-list tbody tr');
        const totalLessons = $lessonRows.length;
        
        if ($searchInput.length > 0) {
            
            // Real-time search
            $searchInput.off('input').on('input', function() {
                const searchTerm = $(this).val().toLowerCase().trim();
                
                if (searchTerm.length > 0) {
                    $searchClear.show();
                    
                    let visibleCount = 0;
                    
                    $lessonRows.each(function() {
                        const $row = $(this);
                        const title = $row.data('search-title') || '';
                        const instructor = $row.data('search-instructor') || '';
                        const notes = $row.data('search-notes') || '';
                        
                        const searchText = title + ' ' + instructor + ' ' + notes;
                        
                        if (searchText.includes(searchTerm)) {
                            $row.show();
                            visibleCount++;
                        } else {
                            $row.hide();
                        }
                    });
                    
                    $searchResults.text('Found ' + visibleCount + ' lesson(s)');
                    
                    if (visibleCount === 0) {
                        if ($('.flm-no-results').length === 0) {
                            $('.flm-list').after('<div class="flm-no-results"><i class="fas fa-search"></i>No lessons found matching your search.</div>');
                        }
                    } else {
                        $('.flm-no-results').remove();
                    }
                    
                } else {
                    clearSearch();
                }
            });
            
            // Clear button
            $searchClear.off('click').on('click', function() {
                clearSearch();
                $searchInput.focus();
            });
            
            // ESC key
            $searchInput.off('keydown').on('keydown', function(e) {
                if (e.key === 'Escape') {
                    clearSearch();
                }
            });
            
            function clearSearch() {
                $searchInput.val('');
                $searchClear.hide();
                $lessonRows.show();
                $searchResults.text('Found ' + totalLessons + ' lesson(s)');
                $('.flm-no-results').remove();
            }
        }
        
        // Notes editing
        $(document).off('click', '.flm-btn-edit-note[data-can-edit="true"]').on('click', '.flm-btn-edit-note[data-can-edit="true"]', function(e) {
            e.preventDefault();
            var $btn = $(this);
            var $row = $btn.closest('tr');
            var $display = $row.find('.flm-notes-display');
            var $edit = $row.find('.flm-notes-edit');
            
            $display.hide();
            $edit.show();
            $row.find('.flm-notes-textarea').focus();
        });
        
        $(document).off('click', '.flm-btn-cancel-note').on('click', '.flm-btn-cancel-note', function(e) {
            e.preventDefault();
            var $btn = $(this);
            var $row = $btn.closest('tr');
            var $display = $row.find('.flm-notes-display');
            var $edit = $row.find('.flm-notes-edit');
            
            $edit.hide();
            $display.show();
        });
        
        $(document).off('click', '.flm-btn-save-note').on('click', '.flm-btn-save-note', function(e) {
            e.preventDefault();
            var $btn = $(this);
            var $row = $btn.closest('tr');
            var lessonId = $btn.data('lesson-id');
            var notes = $row.find('.flm-notes-textarea').val();
            
            var originalText = $btn.text();
            $btn.prop('disabled', true).text('Saving...');
            
            $.ajax({
                url: flmFrontend.ajaxurl,
                type: 'POST',
                data: {
                    action: 'flm_save_notes',
                    nonce: flmFrontend.nonce,
                    lesson_id: lessonId,
                    notes: notes
                },
                success: function(res) {
                    if (res.success) {
                        var displayText = notes ? notes : '<em style="color:#999;">No notes</em>';
                        $row.find('.flm-notes-content').html(displayText);
                        $row.find('.flm-notes-edit').hide();
                        $row.find('.flm-notes-display').show();
                    } else {
                        alert('Failed to save notes: ' + (res.data.message || 'Unknown error'));
                    }
                },
                error: function() {
                    alert('An error occurred while saving notes.');
                },
                complete: function() {
                    $btn.prop('disabled', false).text(originalText);
                }
            });
        });
        
        // Delete lesson
        $(document).off('click', '.flm-btn-delete:not(.disabled)').on('click', '.flm-btn-delete:not(.disabled)', function(e) {
            e.preventDefault();
            
            if (!confirm('Are you sure you want to delete this lesson permanently? This cannot be undone.')) {
                return;
            }
            
            var $btn = $(this);
            var lessonId = $btn.data('lesson-id');
            // Use the nonce from the hidden field. Fallback to global nonce for maximum compatibility.
            var nonce = $('#flm_delete_nonce').val() || flmFrontend.nonce;
            var $row = $btn.closest('tr');
            
            $btn.prop('disabled', true).html('<i class="fas fa-spinner fa-spin"></i>');
            
            $.ajax({
                url: flmFrontend.ajaxurl,
                type: 'POST',
                data: {
                    action: 'flm_delete_lesson',
                    nonce: nonce,
                    lesson_id: lessonId
                },
                success: function(res) {
                    if (res.success) {
                        $row.fadeOut(300, function() {
                            $(this).remove();
                            // Update count
                            var newCount = $('.flm-list tbody tr').length;
                            $('.flm-search-results').text('Found ' + newCount + ' lesson(s)');
                        });
                    } else {
                        // NEW: Show specific error message from PHP
                        alert('Delete Error: ' + (res.data.message || 'Unknown server error.'));
                        $btn.prop('disabled', false).html('<i class="fas fa-trash"></i>');
                    }
                },
                error: function(xhr, status, error) {
                    // NEW: Show generic failure with status code
                    alert('An error occurred while deleting the lesson. (Status: ' + status + ')');
                    $btn.prop('disabled', false).html('<i class="fas fa-trash"></i>');
                }
            });
        });
    }
    
});