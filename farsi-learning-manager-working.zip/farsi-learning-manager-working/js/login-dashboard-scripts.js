/**
 * Login and Dashboard Scripts
 * Version 2.4.1 - Production
 */

jQuery(function($) {
    
    // NEW: Function to load fresh notifications via AJAX
    function flm_load_fresh_notifications() {
        var $container = $('#flm-notifications-container');
        var $countBadge = $('.flm-submissions-count');

        // Check if the notification container exists before running AJAX
        if ($container.length === 0) {
            return;
        }

        $.ajax({
            url: flmFrontend.ajaxurl,
            type: 'POST',
            data: {
                action: 'flm_get_fresh_notifications'
            },
            success: function(res) {
                if (res.success) {
                    // Update main container HTML
                    $container.html(res.data.html);

                    // Update submissions count button
                    if (res.data.count > 0) {
                        $countBadge.text(res.data.count).show();
                    } else {
                        $countBadge.text(0).hide();
                    }
                } else {
                    $container.html('<div class="flm-message error" style="display:block;">Error loading submissions.</div>');
                }
            },
            error: function() {
                $container.html('<div class="flm-message error" style="display:block;">Network error loading submissions.</div>');
            }
        });
    }

    // NEW: Load fresh notifications on dashboard page load (Fixes caching issue 1)
    if ($('#flm-notifications-container').length > 0) {
        flm_load_fresh_notifications();
    }
    
    /* ==========================================================================
       LOGIN FORM
       ========================================================================== */
    
    $('#flm-login-form').on('submit', function(e) {
        e.preventDefault();
        
        var $form = $(this);
        var $btn = $('#flm-login-submit');
        var $btnText = $('.flm-login-btn-text');
        var $btnLoading = $('.flm-login-btn-loading');
        var $msg = $('#flm-login-message');
        
        // Disable button
        $btn.prop('disabled', true);
        $btnText.hide();
        $btnLoading.show();
        $msg.hide();
        
        // Get form data
        var formData = $form.serialize() + '&action=flm_login';
        
        $.ajax({
            url: flmFrontend.ajaxurl,
            type: 'POST',
            data: formData,
            success: function(res) {
                if (res.success) {
                    $msg.removeClass('error').addClass('success').html(res.data.message).show();
                    
                    // Check if 2FA is needed
                    if (res.data.needs_2fa) {
                        setTimeout(function() {
                            window.location.href = res.data.redirect;
                        }, 1000);
                    } else {
                        // Standard login redirect
                        setTimeout(function() {
                            window.location.href = res.data.redirect;
                        }, 1000);
                    }
                } else {
                    $msg.removeClass('success').addClass('error').html(res.data.message).show();
                    $btn.prop('disabled', false);
                    $btnText.show();
                    $btnLoading.hide();
                }
            },
            error: function() {
                $msg.removeClass('success').addClass('error').html('An error occurred. Please try again.').show();
                $btn.prop('disabled', false);
                $btnText.show();
                $btnLoading.hide();
            }
        });
    });
    
    /* ==========================================================================
       2FA VERIFICATION FORM
       ========================================================================== */
    
    // Auto-focus the verification code input
    if ($('#flm-verification-code').length) {
        $('#flm-verification-code').focus();
    }
    
    // 2FA Form submission
    $('#flm-2fa-form').on('submit', function(e) {
        e.preventDefault();
        
        // Get code from single input
        var code = $('#flm-verification-code').val();
        
        if (code.length !== 6) {
            $('#flm-2fa-message').removeClass('success').addClass('error')
                .html('Please enter all 6 digits.').show();
            return;
        }
        
        var $btn = $('#flm-2fa-submit');
        var $msg = $('#flm-2fa-message');
        var trustDevice = $('#flm-trust-device').is(':checked') ? '1' : '0';
        var nonce = $('#flm_2fa_nonce').val();
        
        $btn.prop('disabled', true).html('<i class="fas fa-spinner fa-spin"></i> Verifying...');
        $msg.hide();
        
        $.ajax({
            url: flmFrontend.ajaxurl,
            type: 'POST',
            data: {
                action: 'flm_verify_2fa',
                verification_code: code,
                trust_device: trustDevice,
                flm_2fa_nonce: nonce
            },
            success: function(res) {
                if (res.success) {
                    $msg.removeClass('error').addClass('success').html(res.data.message).show();
                    setTimeout(function() {
                        window.location.href = res.data.redirect;
                    }, 1000);
                } else {
                    $msg.removeClass('success').addClass('error').html(res.data.message).show();
                    $btn.prop('disabled', false).html('Verify Code');
                    $('#flm-verification-code').val('');
                    $('#flm-verification-code').focus();
                }
            },
            error: function() {
                $msg.removeClass('success').addClass('error').html('An error occurred. Please try again.').show();
                $btn.prop('disabled', false).html('Verify Code');
            }
        });
    });
    
    // Resend code
    $('#flm-resend-code').on('click', function(e) {
        e.preventDefault();
        
        var $btn = $(this);
        var $msg = $('#flm-2fa-message');
        
        $btn.prop('disabled', true).html('<i class="fas fa-spinner fa-spin"></i> Sending...');
        $msg.hide();
        
        $.ajax({
            url: flmFrontend.ajaxurl,
            type: 'POST',
            data: {
                action: 'flm_resend_2fa'
            },
            success: function(res) {
                if (res.success) {
                    $msg.removeClass('error').addClass('success').html(res.data.message).show();
                    $btn.prop('disabled', false).html('Resend Code');
                    $('#flm-verification-code').val('');
                    $('#flm-verification-code').focus();
                } else {
                    $msg.removeClass('success').addClass('error').html(res.data.message).show();
                    $btn.prop('disabled', false).html('Resend Code');
                }
            },
            error: function() {
                $msg.removeClass('success').addClass('error').html('An error occurred. Please try again.').show();
                $btn.prop('disabled', false).html('Resend Code');
            }
        });
    });
    
    /* ==========================================================================
       INSTRUCTOR UPLOAD FORM - NATIVE FILE BROWSER (NO MEDIA LIBRARY!)
       ========================================================================== */
    
    // When "Select File" button is clicked, trigger the hidden file input
    $('.flm-btn-select-file').on('click', function(e) {
        e.preventDefault();
        var targetId = $(this).data('target');
        $('#' + targetId).trigger('click'); // Opens native file browser!
    });
    
    // When file is selected, show the filename in the display input
    $('input[type="file"]').on('change', function() {
        var fileName = $(this).val().split('\\').pop(); // Get filename only
        var displayInputId = $(this).attr('id') + '_display';
        $('#' + displayInputId).val(fileName || 'No file selected');
    });
    
    // Instructor form submission with file uploads
    $('#flm-instructor-form').on('submit', function(e) {
        e.preventDefault();
        
        var $btn = $('#flm-instructor-submit');
        var $msg = $('#flm-instructor-message');
        
        // Validate student file is selected
        if (!$('#student_file')[0].files.length) {
            $msg.removeClass('success').addClass('error').html('Please select a student file.').show();
            return;
        }
        
        $btn.prop('disabled', true).text('Uploading files...');
        $msg.hide();
        
        // Use FormData to handle file uploads
        var formData = new FormData(this);
        
        $.ajax({
            url: flmFrontend.ajaxurl,
            type: 'POST',
            data: formData,
            processData: false,
            contentType: false,
            success: function(res) {
                if (res.success) {
                    $msg.removeClass('error').addClass('success').html(res.data.message).show();
                    // Redirect after 1.5 seconds
                    setTimeout(function() {
                        window.location.href = res.data.redirect;
                    }, 1500);
                } else {
                    $msg.removeClass('success').addClass('error').html(res.data.message).show();
                    $btn.prop('disabled', false).text('Create Lesson');
                }
            },
            error: function() {
                $msg.removeClass('success').addClass('error').html('An error occurred. Please try again.').show();
                $btn.prop('disabled', false).text('Create Lesson');
            }
        });
    });
    
    /* ==========================================================================
       DASHBOARD - PROFILE EDITING
       ========================================================================== */
    
    // Show profile edit form
    $('#flm-edit-profile-btn').on('click', function() {
        $('#flm-profile-edit-form').slideDown();
        $(this).hide();
    });
    
    // Cancel profile edit
    $('#flm-cancel-profile-edit').on('click', function() {
        $('#flm-profile-edit-form').slideUp();
        $('#flm-edit-profile-btn').show();
    });
    
    // Update profile form submission
    $('#flm-update-profile-form').on('submit', function(e) {
        e.preventDefault();
        
        var $btn = $(this).find('button[type="submit"]');
        var $msg = $('#flm-profile-message');
        var originalText = $btn.html();
        
        $btn.prop('disabled', true).html('<i class="fas fa-spinner fa-spin"></i> Saving...');
        $msg.hide();
        
        var formData = $(this).serialize() + '&action=flm_update_profile';
        
        $.ajax({
            url: flmFrontend.ajaxurl,
            type: 'POST',
            data: formData,
            success: function(res) {
                if (res.success) {
                    $msg.removeClass('error').addClass('success').html(res.data.message).show();
                    // Reload page after 1.5 seconds to show updated info
                    setTimeout(function() {
                        location.reload();
                    }, 1500);
                } else {
                    $msg.removeClass('success').addClass('error').html(res.data.message).show();
                    $btn.prop('disabled', false).html(originalText);
                }
            },
            error: function() {
                $msg.removeClass('success').addClass('error').html('An error occurred. Please try again.').show();
                $btn.prop('disabled', false).html(originalText);
            }
        });
    });
    
    /* ==========================================================================
       DASHBOARD - NOTIFICATIONS (MARK AS READ)
       ========================================================================== */
    
    // Mark notification as read
    $(document).on('click', '.flm-notification-mark-read', function() {
        var $btn = $(this);
        var notificationId = $btn.data('notification-id');
        var $item = $btn.closest('.flm-notification-item');
        
        $.ajax({
            url: flmFrontend.ajaxurl,
            type: 'POST',
            data: {
                action: 'flm_mark_notification_read',
                notification_id: notificationId
            },
            success: function(res) {
                if (res.success) {
                    $item.slideUp(300, function() {
                        $(this).remove();
                        // Call the function to reload fresh notifications after marking as read
                        flm_load_fresh_notifications();
                    });
                }
            }
        });
    });
    
    /* ==========================================================================
       SUBMISSIONS LIST - DELETE BUTTON (Fixes missing delete button)
       ========================================================================== */
    
    $(document).on('click', '.flm-delete-submission-btn', function(e) {
        e.preventDefault();

        if (!confirm('Are you sure you want to delete this submission permanently? This cannot be undone.')) {
            return;
        }

        var $btn = $(this);
        var submissionId = $btn.data('submission-id');
        var $row = $btn.closest('tr');
        
        $btn.prop('disabled', true).html('<i class="fas fa-spinner fa-spin"></i>');

        $.ajax({
            url: flmFrontend.ajaxurl,
            type: 'POST',
            data: {
                action: 'flm_delete_submission',
                submission_id: submissionId
            },
            success: function(res) {
                if (res.success) {
                    $row.fadeOut(300, function() { 
                        $(this).remove();
                        // For a clean list, you might want to reload the page or update counts, 
                        // but fadeOut provides a clean UX deletion.
                    });
                } else {
                    alert('Error: ' + res.data.message);
                    $btn.prop('disabled', false).html('<i class="fas fa-trash"></i>');
                }
            },
            error: function() {
                alert('An error occurred while deleting the submission.');
                $btn.prop('disabled', false).html('<i class="fas fa-trash"></i>');
            }
        });
    });
    
});