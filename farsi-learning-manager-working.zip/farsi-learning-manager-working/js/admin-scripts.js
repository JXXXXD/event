/**
 * Admin Scripts - Farsi Learning Manager
 */

jQuery(function($) {
    
    /* ==========================================================================
       MEDIA UPLOADER
       ========================================================================== */
    
    $('.flm-upload').on('click', function(e) {
        e.preventDefault();
        var target = $(this).data('target');
        var frame = wp.media({
            title: 'Select File',
            button: { text: 'Use This File' },
            multiple: false
        });
        
        frame.on('select', function() {
            var attachment = frame.state().get('selection').first().toJSON();
            $('#flm_' + target).val(attachment.id);
            $('#flm_' + target + '_url').val(attachment.url);
        });
        
        frame.open();
    });
    
    $('.flm-remove').on('click', function(e) {
        e.preventDefault();
        var target = $(this).data('target');
        $('#flm_' + target).val('');
        $('#flm_' + target + '_url').val('');
    });
    
});
