<?php
/**
 * Plugin Name: Farsi Learning Manager
 * Description: Collaborative Farsi lesson management with student submissions, instructor materials, and security code system
 * Version: 2.4.0
 * Author: JH Photographers
 * Text Domain: farsi-learning-manager
 */

if (!defined('ABSPATH')) exit;

// FIX 1: Ensure essential time constants are defined globally for cron and utilities
if (!defined('DAY_IN_SECONDS')) {
    define('DAY_IN_SECONDS', 86400);
}
if (!defined('HOUR_IN_SECONDS')) {
    define('HOUR_IN_SECONDS', 3600);
}

define('FLM_VERSION', '2.4.0');
define('FLM_PLUGIN_PATH', plugin_dir_path(__FILE__)); // This is the reliable path constant
define('FLM_PLUGIN_URL', plugin_dir_url(__FILE__));

require_once FLM_PLUGIN_PATH . 'includes/user-roles.php';
require_once FLM_PLUGIN_PATH . 'includes/post-types.php';
require_once FLM_PLUGIN_PATH . 'includes/permissions.php';
require_once FLM_PLUGIN_PATH . 'includes/meta-boxes.php';
require_once FLM_PLUGIN_PATH . 'includes/admin-pages.php';
require_once FLM_PLUGIN_PATH . 'includes/shortcodes.php';
require_once FLM_PLUGIN_PATH . 'includes/ajax-handler.php';
require_once FLM_PLUGIN_PATH . 'includes/login-system.php';
require_once FLM_PLUGIN_PATH . 'includes/dashboard.php';
require_once FLM_PLUGIN_PATH . 'includes/list-filters.php';
require_once FLM_PLUGIN_PATH . 'includes/two-factor-auth.php';
require_once FLM_PLUGIN_PATH . 'includes/ajax-fresh-lessons.php';

add_action('admin_enqueue_scripts', 'flm_admin_assets');
function flm_admin_assets($hook) {
    $screen = get_current_screen();
    if ($screen && ($screen->post_type === 'farsi_lesson' || $screen->post_type === 'farsi_submission' || strpos($screen->base, 'farsi-learning') !== false)) {
        wp_enqueue_style('flm-admin-styles', FLM_PLUGIN_URL . 'css/admin-styles.css', array(), FLM_VERSION);
        wp_enqueue_script('flm-admin-scripts', FLM_PLUGIN_URL . 'js/admin-scripts.js', array('jquery'), FLM_VERSION, true);
        wp_enqueue_media();
        wp_localize_script('flm-admin-scripts', 'flmAdmin', array('ajaxurl' => admin_url('admin-ajax.php'), 'nonce' => wp_create_nonce('flm_admin_nonce')));
    }
}

// FIXED: Load CSS/JS on ALL frontend pages to ensure shortcodes work
add_action('wp_enqueue_scripts', 'flm_frontend_assets');
function flm_frontend_assets() {
    // ALWAYS load Font Awesome
    wp_enqueue_style('font-awesome', 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css', array(), '6.4.0');
    
    // ALWAYS load our CSS and JS
    wp_enqueue_style('flm-frontend-styles', FLM_PLUGIN_URL . 'css/frontend-styles.css', array(), FLM_VERSION);
    wp_enqueue_style('flm-login-dashboard-styles', FLM_PLUGIN_URL . 'css/login-dashboard-styles.css', array(), FLM_VERSION);
    
    wp_enqueue_script('flm-frontend-scripts', FLM_PLUGIN_URL . 'js/frontend-scripts.js', array('jquery'), FLM_VERSION, true);
    wp_enqueue_script('flm-login-dashboard-scripts', FLM_PLUGIN_URL . 'js/login-dashboard-scripts.js', array('jquery'), FLM_VERSION, true);
    
    // AJAX Lesson Loader - Always loads fresh data, bypasses ALL cache!
    wp_enqueue_script('flm-ajax-lesson-loader', FLM_PLUGIN_URL . 'js/ajax-lesson-loader.js', array('jquery'), FLM_VERSION, true);
    
    // Localize script with AJAX URL and nonce
    wp_localize_script('flm-frontend-scripts', 'flmFrontend', array(
        'ajaxurl' => admin_url('admin-ajax.php'),
        'nonce' => wp_create_nonce('flm_admin_nonce')
    ));
    
    // If on single lesson page, dashboard, or upload page, also load media library
    if (is_singular('farsi_lesson') || is_page(array('my-dashboard', 'upload-materials'))) {
        wp_enqueue_media();
    }
}

register_activation_hook(__FILE__, 'flm_activate');
function flm_activate() {
    flm_create_custom_roles();
    flm_register_post_types();
    
    // Schedule cron job for daily submission cleanup
    if (!wp_next_scheduled('flm_daily_submission_cleanup')) {
        wp_schedule_event(time(), 'daily', 'flm_daily_submission_cleanup');
    }
    
    $upload_dir = wp_upload_dir();
    $flm_dir = $upload_dir['basedir'] . '/flm-submissions';
    if (!file_exists($flm_dir)) {
        wp_mkdir_p($flm_dir);
        file_put_contents($flm_dir . '/.htaccess', "deny from all\nOptions -Indexes");
    }
    flush_rewrite_rules();
}

register_deactivation_hook(__FILE__, 'flm_deactivate');
function flm_deactivate() {
    // Unschedule the cron event on deactivation
    $timestamp = wp_next_scheduled('flm_daily_submission_cleanup');
    if ($timestamp) {
        wp_unschedule_event($timestamp, 'flm_daily_submission_cleanup');
    }

    flush_rewrite_rules();
}

// Hook the cleanup function to the scheduled event (function definition is in includes/dashboard.php)
add_action('flm_daily_submission_cleanup', 'flm_delete_old_submissions');

add_filter('single_template', 'flm_single_lesson_template');
function flm_single_lesson_template($template) {
    if (is_singular('farsi_lesson')) {
        $plugin_template = FLM_PLUGIN_PATH . 'templates/single-lesson.php';
        if (file_exists($plugin_template)) {
            return $plugin_template;
        }
    }
    return $template;
}