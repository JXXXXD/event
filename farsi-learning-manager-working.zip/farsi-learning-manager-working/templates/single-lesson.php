<?php
/**
 * Template for Single Farsi Lesson - GREY PAGE BACKGROUND
 */

if (!defined('ABSPATH')) exit;

get_header();

while (have_posts()) : the_post();
    
    $lesson_id = get_the_ID();
    $student_file_id = get_post_meta($lesson_id, '_flm_student_file', true);
    $teacher_file_id = get_post_meta($lesson_id, '_flm_teacher_file', true);
    $audio_file_id = get_post_meta($lesson_id, '_flm_audio_file', true);
    $notes = get_post_meta($lesson_id, '_flm_notes', true);
    $author = get_user_by('id', get_the_author_meta('ID'));
    
    $is_admin_or_editor = flm_is_admin_or_editor();
    $can_edit = flm_can_edit_lesson($lesson_id);
    ?>
    
    <style>
        /* GREY PAGE BACKGROUND LIKE LIST PAGE */
        body.single-farsi_lesson {
            background: #f5f5f5 !important; /* GREY PAGE */
        }
        
        /* Override theme's content area if it's white */
        .single-farsi_lesson .site-content,
        .single-farsi_lesson .content-area,
        .single-farsi_lesson main,
        .single-farsi_lesson article {
            background: transparent !important;
        }
        
        .flm-single-wrapper {
            width: 100% !important;
            max-width: 1200px !important;
            margin: 40px auto !important;
            padding: 40px !important;
            background: #fff !important; /* WHITE CONTAINER */
            box-shadow: 0 1px 3px rgba(0,0,0,0.1) !important;
            box-sizing: border-box !important;
        }
        
        .flm-single-header {
            padding: 0 0 30px 0;
            border-bottom: 1px solid #e0e0e0;
            margin-bottom: 30px;
        }
        
        .flm-single-title {
            font-size: 28px;
            font-weight: 700;
            margin: 0 0 10px 0;
            color: #000;
        }
        
        .flm-single-meta {
            color: #666;
            font-size: 14px;
        }
        
        .flm-files-table {
            width: 100%;
            border-collapse: separate;
            border-spacing: 0 8px;
        }
        
        .flm-files-table thead {
            background: transparent;
        }
        
        .flm-files-table th {
            padding: 12px 20px;
            text-align: left;
            font-weight: 600;
            font-size: 11px;
            text-transform: uppercase;
            letter-spacing: 1px;
            color: #666;
            border: none;
            background: transparent;
        }
        
        .flm-files-table tbody tr {
            background: #fff;
            transition: all 0.2s;
        }
        
        .flm-files-table tbody tr:hover {
            transform: translateY(-1px);
            box-shadow: 0 4px 6px rgba(0,0,0,0.05);
        }
        
        .flm-files-table td {
            padding: 18px 20px;
            background: #fff; /* WHITE ROWS */
            vertical-align: middle;
            border-top: 1px solid #e0e0e0;
            border-bottom: 1px solid #e0e0e0;
        }
        
        .flm-files-table td:first-child {
            border-left: 1px solid #e0e0e0;
        }
        
        .flm-files-table td:last-child {
            border-right: 1px solid #e0e0e0;
        }
        
        .flm-files-table tbody tr:hover td {
            border-color: #000;
            background: #fff;
        }
        
        .flm-file-type {
            font-weight: 600;
            color: #000;
            font-size: 14px;
        }
        
        .flm-file-name {
            color: #666;
            font-size: 13px;
            font-family: 'Monaco', 'Menlo', monospace;
        }
        
        .flm-file-empty {
            color: #999;
            font-style: italic;
            font-size: 13px;
        }
        
        .flm-file-actions {
            white-space: nowrap;
        }
        
        .flm-btn-small {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            width: 32px;
            height: 32px;
            border-radius: 0;
            text-decoration: none;
            cursor: pointer;
            border: 1px solid #000;
            transition: all 0.2s;
            margin-right: 6px;
            overflow: visible;
            vertical-align: middle;
            font-size: 16px;
        }
        
        .flm-btn-download {
            background-color: #000;
            color: #fff;
            border-color: #000;
        }
        
        .flm-btn-download:hover {
            background-color: #333;
            color: #fff;
        }
        
        .flm-btn-copy {
            background-color: #fff;
            color: #000;
            border: 1px solid #000;
        }
        
        .flm-btn-copy:hover {
            background-color: #000;
            color: #fff;
        }
        
        .flm-btn-copy.copied {
            background-color: #10b981;
            color: #fff;
            border-color: #10b981;
        }
        
        .flm-btn-edit-inline {
            background-color: #fff;
            color: #000;
            border: 1px solid #000;
        }
        
        .flm-btn-edit-inline:hover {
            background-color: #000;
            color: #fff;
        }
        
        .flm-btn-delete {
            background-color: #ff0000;
            color: #fff;
            border: 1px solid #ff0000;
        }
        
        .flm-btn-delete:hover {
            background-color: #cc0000;
            border-color: #cc0000;
            color: #fff;
        }
        
        .flm-btn-play {
            background-color: #000;
            color: #fff;
            width: 32px;
            height: 32px;
            border-radius: 0;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            padding: 0;
            margin-right: 10px;
            border: 1px solid #000;
            font-size: 14px;
            cursor: pointer;
        }
        
        .flm-btn-play:hover {
            background-color: #333;
            color: #fff;
        }
        
        .flm-edit-row {
            display: none;
        }
        
        .flm-edit-row.active {
            display: table-row;
        }
        
        .flm-edit-row td {
            background: #f5f5f5 !important;
            padding: 20px !important;
            border-top: 1px solid #000 !important;
        }
        
        .flm-upload-field {
            display: flex;
            gap: 10px;
            align-items: center;
            margin-bottom: 15px;
        }
        
        .flm-upload-field input[type="text"] {
            flex: 1;
            padding: 10px 14px;
            border: 1px solid #000;
            border-radius: 0;
            font-size: 13px;
            background: #fff;
        }
        
        .flm-upload-field input[type="text"]:focus {
            outline: none;
            border-color: #000;
            box-shadow: inset 0 0 0 1px #000;
        }
        
        .flm-btn-save {
            background: #000;
            color: #fff;
            padding: 10px 20px;
            border: 1px solid #000;
            border-radius: 0;
            cursor: pointer;
            font-weight: 700;
            font-size: 12px;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        
        .flm-btn-save:hover {
            background: #333;
        }
        
        .flm-btn-cancel {
            background: #fff;
            color: #000;
            padding: 10px 20px;
            border: 1px solid #000;
            border-radius: 0;
            cursor: pointer;
            font-weight: 700;
            font-size: 12px;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            margin-left: 8px;
        }
        
        .flm-btn-cancel:hover {
            background: #f5f5f5;
        }
        
        .flm-audio-hidden {
            display: none;
        }
    </style>
    
    <div class="flm-single-wrapper">
        
        <div class="flm-single-header">
            <h1 class="flm-single-title"><?php the_title(); ?></h1>
            <div class="flm-single-meta">
                <strong>Instructor:</strong> <?php echo esc_html($author->display_name); ?>
                <?php if ($notes && $is_admin_or_editor) : ?>
                    | <strong>Notes:</strong> <?php echo esc_html($notes); ?>
                <?php endif; ?>
            </div>
        </div>
        
        <table class="flm-files-table">
            <thead>
                <tr>
                    <th style="width: 15%;">File Type</th>
                    <th style="width: 35%;">File Name</th>
                    <th style="width: 50%;">Actions</th>
                </tr>
            </thead>
            <tbody>
                
                <tr id="student-file-row">
                    <td>
                        <span class="flm-file-type">Student File</span>
                    </td>
                    <td>
                        <?php if ($student_file_id) : 
                            $file_name = basename(get_attached_file($student_file_id));
                        ?>
                            <span class="flm-file-name"><?php echo esc_html($file_name); ?></span>
                        <?php else : ?>
                            <span class="flm-file-empty">No file uploaded</span>
                        <?php endif; ?>
                    </td>
                    <td class="flm-file-actions">
                        <?php if ($student_file_id) : 
                            $file_url = wp_get_attachment_url($student_file_id);
                        ?>
                            <a href="<?php echo esc_url($file_url); ?>" class="flm-btn-small flm-btn-download" download><i class="fas fa-download"></i></a>
                            <button class="flm-btn-small flm-btn-copy" data-url="<?php echo esc_url($file_url); ?>"><i class="fas fa-copy"></i></button>
                        <?php endif; ?>
                        <?php if ($can_edit) : ?>
                            <button class="flm-btn-small flm-btn-edit-inline" data-target="student"><i class="fas fa-pen"></i></button>
                            <?php if ($student_file_id) : ?>
                                <button class="flm-btn-small flm-btn-delete" data-type="student" data-lesson="<?php echo $lesson_id; ?>"><i class="fas fa-trash"></i></button>
                            <?php endif; ?>
                        <?php endif; ?>
                    </td>
                </tr>
                
                <?php if ($can_edit) : ?>
                <tr class="flm-edit-row" id="student-edit-row">
                    <td colspan="3">
                        <div class="flm-upload-field">
                            <input type="hidden" id="student-file-id" value="<?php echo esc_attr($student_file_id); ?>">
                            <input type="text" id="student-file-display" value="<?php echo $student_file_id ? esc_html(basename(get_attached_file($student_file_id))) : 'No file selected'; ?>" readonly>
                            <button class="flm-btn-save flm-media-upload" data-target="student">Select File</button>
                        </div>
                        <div>
                            <button class="flm-btn-save" data-type="student" data-lesson="<?php echo $lesson_id; ?>">Save Changes</button>
                            <button class="flm-btn-cancel" data-target="student">Cancel</button>
                        </div>
                    </td>
                </tr>
                <?php endif; ?>
                
                <tr id="teacher-file-row">
                    <td>
                        <span class="flm-file-type">Teacher File</span>
                    </td>
                    <td>
                        <?php if ($teacher_file_id) : 
                            $file_name = basename(get_attached_file($teacher_file_id));
                        ?>
                            <span class="flm-file-name"><?php echo esc_html($file_name); ?></span>
                        <?php else : ?>
                            <span class="flm-file-empty">No file uploaded</span>
                        <?php endif; ?>
                    </td>
                    <td class="flm-file-actions">
                        <?php if ($teacher_file_id) : 
                            $file_url = wp_get_attachment_url($teacher_file_id);
                        ?>
                            <a href="<?php echo esc_url($file_url); ?>" class="flm-btn-small flm-btn-download" download><i class="fas fa-download"></i></a>
                            <button class="flm-btn-small flm-btn-copy" data-url="<?php echo esc_url($file_url); ?>"><i class="fas fa-copy"></i></button>
                        <?php endif; ?>
                        <?php if ($can_edit) : ?>
                            <button class="flm-btn-small flm-btn-edit-inline" data-target="teacher"><i class="fas fa-pen"></i></button>
                            <?php if ($teacher_file_id) : ?>
                                <button class="flm-btn-small flm-btn-delete" data-type="teacher" data-lesson="<?php echo $lesson_id; ?>"><i class="fas fa-trash"></i></button>
                            <?php endif; ?>
                        <?php endif; ?>
                    </td>
                </tr>
                
                <?php if ($can_edit) : ?>
                <tr class="flm-edit-row" id="teacher-edit-row">
                    <td colspan="3">
                        <div class="flm-upload-field">
                            <input type="hidden" id="teacher-file-id" value="<?php echo esc_attr($teacher_file_id); ?>">
                            <input type="text" id="teacher-file-display" value="<?php echo $teacher_file_id ? esc_html(basename(get_attached_file($teacher_file_id))) : 'No file selected'; ?>" readonly>
                            <button class="flm-btn-save flm-media-upload" data-target="teacher">Select File</button>
                        </div>
                        <div>
                            <button class="flm-btn-save" data-type="teacher" data-lesson="<?php echo $lesson_id; ?>">Save Changes</button>
                            <button class="flm-btn-cancel" data-target="teacher">Cancel</button>
                        </div>
                    </td>
                </tr>
                <?php endif; ?>
                
                <tr id="audio-file-row">
                    <td>
                        <span class="flm-file-type">Audio File</span>
                    </td>
                    <td>
                        <?php if ($audio_file_id) : 
                            $file_name = basename(get_attached_file($audio_file_id));
                            $audio_url = wp_get_attachment_url($audio_file_id);
                        ?>
                            <span class="flm-file-name"><?php echo esc_html($file_name); ?></span>
                            <audio id="audio-player" class="flm-audio-hidden">
                                <source src="<?php echo esc_url($audio_url); ?>" type="audio/mpeg">
                            </audio>
                        <?php else : ?>
                            <span class="flm-file-empty">No file uploaded</span>
                        <?php endif; ?>
                    </td>
                    <td class="flm-file-actions">
                        <?php if ($audio_file_id) : ?>
                            <button class="flm-btn-play" id="flm-audio-control"><i class="fas fa-play"></i></button>
                            <a href="<?php echo esc_url($audio_url); ?>" class="flm-btn-small flm-btn-download" download><i class="fas fa-download"></i></a>
                            <button class="flm-btn-small flm-btn-copy" data-url="<?php echo esc_url($audio_url); ?>"><i class="fas fa-copy"></i></button>
                        <?php endif; ?>
                        <?php if ($can_edit) : ?>
                            <button class="flm-btn-small flm-btn-edit-inline" data-target="audio"><i class="fas fa-pen"></i></button>
                            <?php if ($audio_file_id) : ?>
                                <button class="flm-btn-small flm-btn-delete" data-type="audio" data-lesson="<?php echo $lesson_id; ?>"><i class="fas fa-trash"></i></button>
                            <?php endif; ?>
                        <?php endif; ?>
                    </td>
                </tr>
                
                <?php if ($can_edit) : ?>
                <tr class="flm-edit-row" id="audio-edit-row">
                    <td colspan="3">
                        <div class="flm-upload-field">
                            <input type="hidden" id="audio-file-id" value="<?php echo esc_attr($audio_file_id); ?>">
                            <input type="text" id="audio-file-display" value="<?php echo $audio_file_id ? esc_html(basename(get_attached_file($audio_file_id))) : 'No file selected'; ?>" readonly>
                            <button class="flm-btn-save flm-media-upload" data-target="audio">Select File</button>
                        </div>
                        <div>
                            <button class="flm-btn-save" data-type="audio" data-lesson="<?php echo $lesson_id; ?>">Save Changes</button>
                            <button class="flm-btn-cancel" data-target="audio">Cancel</button>
                        </div>
                    </td>
                </tr>
                <?php endif; ?>
                
            </tbody>
        </table>
        
        <?php if ($can_edit || $audio_file_id) : ?>
        <script>
        jQuery(function($) {
            $('#flm-audio-control').on('click', function() {
                var audio = document.getElementById('audio-player');
                var $btn = $(this);
                var $icon = $btn.find('i');
                if (audio.paused) {
                    audio.play();
                    $icon.removeClass('fa-play').addClass('fa-pause');
                } else {
                    audio.pause();
                    $icon.removeClass('fa-pause').addClass('fa-play');
                }
            });
            
            var audioPlayer = document.getElementById('audio-player');
            if (audioPlayer) {
                audioPlayer.onended = function() {
                    $('#flm-audio-control').find('i').removeClass('fa-pause').addClass('fa-play');
                };
            }
            
            $('.flm-btn-edit-inline').on('click', function() {
                var target = $(this).data('target');
                $('#' + target + '-edit-row').addClass('active');
                $('#' + target + '-file-row').hide();
            });
            
            $('.flm-btn-cancel').on('click', function() {
                var target = $(this).data('target');
                $('#' + target + '-edit-row').removeClass('active');
                $('#' + target + '-file-row').show();
            });
            
            $('.flm-media-upload').on('click', function(e) {
                e.preventDefault();
                var target = $(this).data('target');
                var frame = wp.media({title: 'Select File', button: {text: 'Use This File'}, multiple: false});
                frame.on('select', function() {
                    var attachment = frame.state().get('selection').first().toJSON();
                    $('#' + target + '-file-id').val(attachment.id);
                    $('#' + target + '-file-display').val(attachment.filename);
                });
                frame.open();
            });
            
            $('.flm-btn-save').on('click', function() {
                var $btn = $(this);
                var type = $btn.data('type');
                var lessonId = $btn.data('lesson');
                var fileId = $('#' + type + '-file-id').val();
                $btn.prop('disabled', true).text('Saving...');
                $.post(ajaxurl, {action: 'flm_update_file', lesson_id: lessonId, file_type: type, file_id: fileId}, function(res) {
                    if (res.success) {
                        location.reload();
                    } else {
                        alert('Error: ' + res.data.message);
                        $btn.prop('disabled', false).text('Save Changes');
                    }
                });
            });
            
            $('.flm-btn-delete').on('click', function() {
                if (!confirm('Are you sure you want to delete this file?')) return;
                var $btn = $(this);
                var type = $btn.data('type');
                var lessonId = $btn.data('lesson');
                $btn.prop('disabled', true).text('Deleting...');
                $.post(ajaxurl, {action: 'flm_delete_file', lesson_id: lessonId, file_type: type}, function(res) {
                    if (res.success) {
                        location.reload();
                    } else {
                        alert('Error: ' + res.data.message);
                        $btn.prop('disabled', false).text('Delete');
                    }
                });
            });
            
            $('.flm-btn-copy').on('click', function() {
                var $btn = $(this);
                var url = $btn.data('url');
                var $temp = $('<input>');
                $('body').append($temp);
                $temp.val(url).select();
                document.execCommand('copy');
                $temp.remove();
                $btn.addClass('copied').html('<i class="fas fa-check"></i>');
                setTimeout(function() {
                    $btn.removeClass('copied').html('<i class="fas fa-copy"></i>');
                }, 2000);
            });
        });
        </script>
        <?php endif; ?>
        
    </div>
    
    <?php
endwhile;

get_footer();
