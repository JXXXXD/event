<?php
/**
 * Custom Login System
 * Handles login page, redirects, and authentication
 */

if (!defined('ABSPATH')) exit;

/* ==========================================================================
   CUSTOM LOGIN SHORTCODE
   ========================================================================== */

add_shortcode('farsi_login', 'flm_login_shortcode');
function flm_login_shortcode() {
    if (is_user_logged_in()) {
        $redirect_url = current_user_can('administrator') ? admin_url() : home_url('/my-dashboard/');
        ob_start();
        ?>
        <div class="flm-login-wrapper">
            <div class="flm-login-container" style="text-align: center; padding: 60px 40px;">
                <div style="font-size: 48px; color: #28a745; margin-bottom: 20px;"><i class="fas fa-check-circle"></i></div>
                <h2 style="margin: 0 0 10px 0;">Already Logged In</h2>
                <p style="color: #666;">Redirecting to dashboard...</p>
                <script>setTimeout(function(){window.location.href='<?php echo esc_js($redirect_url); ?>';}, 1000);</script>
            </div>
        </div>
        <?php
        return ob_get_clean();
    }
    
    ob_start();
    ?>
    <div class="flm-login-wrapper">
        <div class="flm-login-container">
            <div class="flm-login-logo">
                <img src="<?php echo esc_url(home_url('/wp-content/uploads/2025/12/logo-admin.png')); ?>" alt="Logo">
            </div>
            <form id="flm-login-form" method="post">
                <?php wp_nonce_field('flm_login_action', 'flm_login_nonce'); ?>
                <div class="flm-login-field">
                    <label>Email Address</label>
                    <input type="email" name="user_email" required placeholder="your@email.com">
                </div>
                <div class="flm-login-field">
                    <label>Password</label>
                    <input type="password" name="user_password" required placeholder="Enter password">
                </div>
                <div class="flm-login-remember">
                    <label><input type="checkbox" name="remember_me" value="1"> <span>Remember Me</span></label>
                </div>
                <button type="submit" class="flm-login-btn" id="flm-login-submit">
                    <span class="flm-login-btn-text">Log In</span>
                    <span class="flm-login-btn-loading" style="display:none;"><i class="fas fa-spinner fa-spin"></i> Logging in...</span>
                </button>
                <div id="flm-login-message" class="flm-login-message" style="display:none;"></div>
            </form>
            <div class="flm-login-footer"><a href="<?php echo wp_lostpassword_url(); ?>">Forgot Password?</a></div>
        </div>
    </div>
    <?php
    return ob_get_clean();
}

/* ==========================================================================
   LOGIN AJAX HANDLER
   ========================================================================== */

add_action('wp_ajax_nopriv_flm_login', 'flm_handle_login');
function flm_handle_login() {
    if (!isset($_POST['flm_login_nonce']) || !wp_verify_nonce($_POST['flm_login_nonce'], 'flm_login_action')) {
        wp_send_json_error(array('message' => 'Security check failed.'));
    }
    
    $email = sanitize_email($_POST['user_email']);
    $password = $_POST['user_password'];
    $remember = isset($_POST['remember_me']) && $_POST['remember_me'] == '1';
    
    $user = get_user_by('email', $email);
    
    if (!$user || !wp_check_password($password, $user->user_pass, $user->ID)) {
        wp_send_json_error(array('message' => 'Invalid email or password.'));
    }
    
    // CHECK 2FA
    if (defined('FLM_2FA_ENABLED') && FLM_2FA_ENABLED && !flm_is_device_trusted($user->ID)) {
        if (flm_send_2fa_code($user->ID)) {
            
            // 1. Try to set cookie (Root path)
            setcookie('flm_2fa_pending', $user->ID, time() + 3600, '/'); 
            
            if ($remember) {
                setcookie('flm_remember_me', '1', time() + 3600, '/');
            }

            // 2. Generate URL Fallback (Bypasses cookie issues)
            // We create a hash to ensure the ID in the URL is legitimate
            $token = wp_hash($user->ID . 'flm_2fa_fallback');
            $redirect_url = home_url('/verify-2fa/') . '?uid=' . $user->ID . '&t=' . $token;
            
            wp_send_json_success(array(
                'message' => 'Verification code sent.',
                'redirect' => $redirect_url, // Send to URL with params
                'needs_2fa' => true
            ));
        } else {
            wp_send_json_error(array('message' => 'Failed to send code.'));
        }
        return;
    }
    
    // Normal Login (No 2FA)
    wp_clear_auth_cookie();
    wp_set_current_user($user->ID);
    wp_set_auth_cookie($user->ID, $remember);
    
    $redirect = user_can($user, 'administrator') ? admin_url() : home_url('/my-dashboard/');
    if (isset($_COOKIE['flm_redirect_after_login'])) {
        $redirect = $_COOKIE['flm_redirect_after_login'];
        setcookie('flm_redirect_after_login', '', time() - 3600, '/');
    }
    
    wp_send_json_success(array('message' => 'Login successful!', 'redirect' => $redirect));
}

/* ==========================================================================
   PROTECT PAGES - GATEKEEPER
   ========================================================================== */

add_action('template_redirect', 'flm_protect_pages', 1);
function flm_protect_pages() {
    if (is_user_logged_in() || is_admin()) return;

    global $post;

    // Force Allow Verify Page
    $request_uri = $_SERVER['REQUEST_URI'];
    if (strpos($request_uri, '/verify-2fa') !== false || (isset($post->post_name) && $post->post_name === 'verify-2fa')) {
        return; 
    }
    
    if ($post && ($post->post_name == 'login' || is_page('login'))) return;

    $protected_slugs = array('my-dashboard', 'user-profile-page', 'upload-materials', 'my-lessons', 'material-list', 'instructor-upload', 'dashboard');
    $protected_shortcodes = array('farsi_dashboard', 'farsi_profile', 'farsi_instructor_form', 'farsi_my_lessons');

    $should_protect = false;
    if ($post && in_array($post->post_name, $protected_slugs)) $should_protect = true;
    if ($post && isset($post->post_content)) {
        foreach ($protected_shortcodes as $sc) {
            if (has_shortcode($post->post_content, $sc)) $should_protect = true;
        }
    }

    if ($should_protect) {
        setcookie('flm_redirect_after_login', $_SERVER['REQUEST_URI'], time() + 3600, '/');
        wp_safe_redirect(home_url('/login/'));
        exit;
    }
}

// Redirect helpers
add_action('login_init', 'flm_redirect_login_page');
function flm_redirect_login_page() {
    if (!defined('DOING_AJAX') && !isset($_GET['action'])) {
        wp_safe_redirect(home_url('/login/'));
        exit;
    }
}
add_action('admin_init', 'flm_redirect_non_admin');
function flm_redirect_non_admin() {
    if (!defined('DOING_AJAX') && !is_user_logged_in()) {
        wp_redirect(home_url('/login/'));
        exit;
    }
}
add_action('wp_logout', 'flm_logout_redirect');
function flm_logout_redirect() {
    wp_redirect(home_url('/login/'));
    exit;
}