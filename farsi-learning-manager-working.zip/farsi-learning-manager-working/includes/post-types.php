<?php
/**
 * Custom Post Types
 */

if (!defined('ABSPATH')) exit;

add_action('init', 'flm_register_post_types');
function flm_register_post_types() {
    
    // Lesson CPT
    register_post_type('farsi_lesson', array(
        'labels' => array(
            'name'               => 'Lessons',
            'singular_name'      => 'Lesson',
            'menu_name'          => 'Farsi Lessons',
            'add_new'            => 'Add New Lesson',
            'add_new_item'       => 'Add New Lesson',
            'edit_item'          => 'Edit Lesson',
            'new_item'           => 'New Lesson',
            'view_item'          => 'View Lesson',
            'search_items'       => 'Search Lessons',
            'not_found'          => 'No lessons found',
            'not_found_in_trash' => 'No lessons found in trash',
        ),
        'public'              => true,
        'publicly_queryable'  => true,
        'show_ui'             => true,
        'show_in_menu'        => 'farsi-learning-manager',
        'query_var'           => true,
        'rewrite'             => array('slug' => 'farsi-lesson'),
        'capability_type'     => 'post',
        'has_archive'         => true,
        'hierarchical'        => false,
        'supports'            => array('title', 'author', 'thumbnail'),
        'show_in_rest'        => true,
    ));
    
    // Submission CPT
    register_post_type('farsi_submission', array(
        'labels' => array(
            'name'               => 'Submissions',
            'singular_name'      => 'Submission',
            'menu_name'          => 'Submissions',
            'add_new'            => 'Add New',
            'add_new_item'       => 'Add New Submission',
            'edit_item'          => 'Edit Submission',
            'new_item'           => 'New Submission',
            'view_item'          => 'View Submission',
            'search_items'       => 'Search Submissions',
            'not_found'          => 'No submissions found',
            'not_found_in_trash' => 'No submissions found in trash',
        ),
        'public'              => false,
        'publicly_queryable'  => false,
        'show_ui'             => true,
        'show_in_menu'        => 'farsi-learning-manager',
        'query_var'           => false,
        'rewrite'             => false,
        'capability_type'     => 'post',
        'has_archive'         => false,
        'hierarchical'        => false,
        'supports'            => array('title'),
        'show_in_rest'        => false,
    ));
}
