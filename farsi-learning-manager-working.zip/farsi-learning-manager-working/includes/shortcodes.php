<?php
/**
 * Shortcodes - CONSISTENT STYLING
 */

if (!defined('ABSPATH')) exit;

/* ==========================================================================
   INSTRUCTOR UPLOAD FORM
   ========================================================================== */

add_shortcode('farsi_instructor_form', 'flm_instructor_form_shortcode');
function flm_instructor_form_shortcode() {
    
    // If not logged in, redirect with JavaScript (failsafe)
    if (!is_user_logged_in()) {
        ?>
        <script type="text/javascript">
            window.location.replace('<?php echo esc_js(home_url('/login/')); ?>');
        </script>
        <noscript>
            <meta http-equiv="refresh" content="0;url=<?php echo esc_url(home_url('/login/')); ?>">
        </noscript>
        <?php
        exit; // Stop all further execution
    }
    
    // Must have permission to create posts
    if (!current_user_can('edit_posts')) {
        return '<p>You do not have permission to upload lessons.</p>';
    }
    
    ob_start();
    ?>
    
    <div class="flm-form-container">
        
        <div class="flm-form-header">
            <h1 class="flm-form-title">Upload New Lesson</h1>
            <p class="flm-form-description">Create a new lesson with materials for students</p>
        </div>
        
        <form id="flm-instructor-form" enctype="multipart/form-data">
            <?php wp_nonce_field('flm_instructor_upload', 'flm_instructor_nonce'); ?>
            <input type="hidden" name="action" value="flm_instructor_upload">
            
            <div class="flm-form-row">
                <label>Lesson Title *</label>
                <input type="text" name="lesson_title" required placeholder="e.g., RC - Lesson 1 - Ch 2 - Level 2 - Immigration">
                <p class="flm-note">Use format: [Category] - Lesson [#] - Ch [#] - Level [#] - [Topic]</p>
            </div>
            
            <div class="flm-form-row">
                <label>Notes (Optional)</label>
                <textarea name="lesson_notes" rows="3" placeholder="Internal notes about this lesson..."></textarea>
            </div>
            
            <div class="flm-form-row">
                <label>Student File (PDF/Word) *</label>
                <div class="flm-file-upload-wrapper">
                    <input type="file" name="student_file" id="student_file" accept=".pdf,.doc,.docx" required style="display:none;">
                    <input type="text" id="student_file_display" readonly placeholder="No file selected" class="flm-file-display-input">
                    <button type="button" class="flm-btn-select-file" data-target="student_file">
                        <i class="fas fa-upload"></i> Select File
                    </button>
                </div>
                <p class="flm-note">The file students will download to complete</p>
            </div>
            
            <div class="flm-form-row">
                <label>Teacher File / Answer Key (PDF/Word)</label>
                <div class="flm-file-upload-wrapper">
                    <input type="file" name="teacher_file" id="teacher_file" accept=".pdf,.doc,.docx" style="display:none;">
                    <input type="text" id="teacher_file_display" readonly placeholder="No file selected" class="flm-file-display-input">
                    <button type="button" class="flm-btn-select-file" data-target="teacher_file">
                        <i class="fas fa-upload"></i> Select File
                    </button>
                </div>
                <p class="flm-note">The answer key sent to students after submission</p>
            </div>
            
            <div class="flm-form-row">
                <label>Audio File (Optional - MP3)</label>
                <div class="flm-file-upload-wrapper">
                    <input type="file" name="audio_file" id="audio_file" accept=".mp3,.wav" style="display:none;">
                    <input type="text" id="audio_file_display" readonly placeholder="No file selected" class="flm-file-display-input">
                    <button type="button" class="flm-btn-select-file" data-target="audio_file">
                        <i class="fas fa-upload"></i> Select File
                    </button>
                </div>
                <p class="flm-note">Optional audio accompaniment</p>
            </div>
            
            <button type="submit" class="flm-submit-btn" id="flm-instructor-submit">Create Lesson</button>
            <div id="flm-instructor-message" class="flm-message" style="display:none;"></div>
        </form>
    </div>
    
    <?php
    return ob_get_clean();
}

/* ==========================================================================
   GENERAL SUBMISSION FORM
   ========================================================================== */

add_shortcode('farsi_student_form', 'flm_student_form_shortcode');
function flm_student_form_shortcode($atts) {
    ob_start();
    ?>
    
    <div class="flm-form-container">
        
        <div class="flm-form-header">
            <h1 class="flm-form-title">Submit Your Work</h1>
            <p class="flm-form-description">Upload your completed assignments for review</p>
        </div>
        
        <form id="flm-form" enctype="multipart/form-data">
            <?php wp_nonce_field('flm_submit_work', 'flm_nonce'); ?>
            <input type="hidden" name="action" value="flm_submit_work">
            
            <div class="flm-form-row">
                <label>Student Email *</label>
                <input type="email" name="student_email" required placeholder="student@example.com">
            </div>
            
            <div class="flm-form-row">
                <label>Mentor Email *</label>
                <input type="email" name="mentor_email" required placeholder="mentor@example.com">
                <p class="flm-note">Your mentor will receive your submission</p>
            </div>
            
            <div class="flm-form-row">
                <label>Subject / Lesson Name *</label>
                <input type="text" name="subject" required placeholder="e.g., Immigration Lesson, Week 5 Assignment">
                <p class="flm-note">What is this submission for?</p>
            </div>
            
            <div class="flm-form-row">
                <label>Security Code *</label>
                <div class="flm-security-code-wrapper">
                    <input type="text" name="security_code" id="flm-security-code" required placeholder="Enter security code" autocomplete="off">
                    <span class="flm-code-status" id="flm-code-status"></span>
                </div>
                <p class="flm-note" id="flm-code-note">Contact your administrator for the security code</p>
            </div>
            
            <div class="flm-form-row">
                <label>Upload Your Files *</label>
                <div id="flm-uploads-container">
                    <div class="flm-upload-row" data-upload="1">
                        <input type="file" name="submission_files[]" accept=".pdf,.doc,.docx" required>
                    </div>
                </div>
                <button type="button" id="flm-add-file" class="flm-btn-add-file">
                    <i class="fas fa-plus"></i> Add Another File
                </button>
                <p class="flm-note">Accepted: PDF, Word documents (max 10MB each)</p>
            </div>
            
            <div class="flm-form-row">
                <label>Additional Notes (Optional)</label>
                <textarea name="notes" rows="3" placeholder="Any questions or comments for your mentor..."></textarea>
            </div>
            
            <button type="submit" class="flm-submit-btn" id="flm-submit" disabled>Submit</button>
            <div id="flm-message" class="flm-message" style="display:none;"></div>
        </form>
    </div>
    
    <?php
    return ob_get_clean();
}

/* ==========================================================================
   LESSON LIST
   ========================================================================== */

add_shortcode('farsi_lesson_list', 'flm_lesson_list_shortcode');
function flm_lesson_list_shortcode() {
    wp_enqueue_style('font-awesome', 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css', array(), '6.4.0');
    
    // MODIFIED: No longer querying the database here. AJAX will load data fresh.
    return flm_render_lesson_list(array(), 'All Lessons');
}

/* ==========================================================================
   MY LESSONS (INSTRUCTOR'S OWN LESSONS)
   ========================================================================== */

add_shortcode('farsi_my_lessons', 'flm_my_lessons_shortcode');
function flm_my_lessons_shortcode() {
    // If not logged in, redirect with JavaScript (failsafe)
    if (!is_user_logged_in()) {
        ?>
        <script type="text/javascript">
            window.location.replace('<?php echo esc_js(home_url('/login/')); ?>');
        </script>
        <noscript>
            <meta http-equiv="refresh" content="0;url=<?php echo esc_url(home_url('/login/')); ?>">
        </noscript>
        <?php
        exit; // Stop all further execution
    }
    
    wp_enqueue_style('font-awesome', 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css', array(), '6.4.0');
    
    // MODIFIED: No longer querying the database here. AJAX will load data fresh.
    return flm_render_lesson_list(array(), 'My Lessons');
}

/* ==========================================================================
   SHARED LESSON LIST RENDERING FUNCTION
   ========================================================================== */

function flm_render_lesson_list($lessons, $title = 'Lessons') {
    $current_user_id = get_current_user_id();
    $can_view_dashboard = current_user_can('edit_posts');
    $delete_nonce = wp_create_nonce('flm_delete_lesson');
    
    ob_start();
    ?>
    
    <div class="flm-list-wrapper" data-list-type="<?php echo esc_attr(str_replace(' ', '-', strtolower($title))); ?>">
        <input type="hidden" id="flm_delete_nonce" value="<?php echo esc_attr($delete_nonce); ?>">
        
        <div class="flm-search-container">
            <div class="flm-search-field">
                <i class="fas fa-search flm-search-icon"></i>
                <input type="text" id="flm-lesson-search" placeholder="Search your lessons..." autocomplete="off">
                <button type="button" id="flm-search-clear" class="flm-search-clear" style="display:none;">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            <div class="flm-search-results" id="flm-search-results">
                Found 0 lesson(s)
            </div>
        </div>
        
        <table class="flm-list">
            <thead>
                <tr>
                    <th style="width: 25%;">Title</th>
                    <th style="width: 20%;">Instructor</th>
                    <th style="width: 10%;">View</th>
                    <?php if ($can_view_dashboard) : ?>
                    <th style="width: 35%;">Notes</th>
                    <th style="width: 10%;">Actions</th>
                    <?php endif; ?>
                </tr>
            </thead>
            <tbody>
            <?php // The content is now loaded by JavaScript via AJAX. ?>
            </tbody>
        </table>
    </div>
    
    <?php
    return ob_get_clean();
}