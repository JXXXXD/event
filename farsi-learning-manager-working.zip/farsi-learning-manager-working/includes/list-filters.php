<?php
/**
 * Lesson List Filters
 * Adds filtering to both "All Lessons" and "My Lessons" views
 */

if (!defined('ABSPATH')) exit;

/* ==========================================================================
   ADD FILTER DROPDOWNS TO LESSON LIST
   ========================================================================== */

add_action('restrict_manage_posts', 'flm_add_lesson_filters');
function flm_add_lesson_filters($post_type) {
    if ($post_type !== 'farsi_lesson') {
        return;
    }
    
    // Filter by Instructor (only for admins/team leaders/chairpersons)
    $current_user = wp_get_current_user();
    $show_instructor_filter = in_array('administrator', $current_user->roles) || 
                              in_array('flm_team_leader', $current_user->roles) || 
                              in_array('flm_chairperson', $current_user->roles);
    
    if ($show_instructor_filter) {
        $selected_author = isset($_GET['filter_instructor']) ? intval($_GET['filter_instructor']) : '';
        
        // Get all instructors
        $instructors = get_users(array(
            'role__in' => array('flm_instructor', 'flm_chairperson', 'flm_team_leader', 'administrator'),
            'orderby' => 'display_name',
            'order' => 'ASC'
        ));
        
        if (!empty($instructors)) {
            echo '<select name="filter_instructor" id="filter_instructor">';
            echo '<option value="">All Instructors</option>';
            foreach ($instructors as $instructor) {
                $selected = ($selected_author == $instructor->ID) ? 'selected' : '';
                echo '<option value="' . esc_attr($instructor->ID) . '" ' . $selected . '>' . esc_html($instructor->display_name) . '</option>';
            }
            echo '</select>';
        }
    }
    
    // Search by Title (available to all)
    $search_title = isset($_GET['search_lesson_title']) ? sanitize_text_field($_GET['search_lesson_title']) : '';
    echo '<input type="text" name="search_lesson_title" placeholder="Search lesson title..." value="' . esc_attr($search_title) . '" style="margin-left: 5px;">';
}

/* ==========================================================================
   APPLY FILTERS TO QUERY
   ========================================================================== */

add_filter('parse_query', 'flm_filter_lessons_by_query');
function flm_filter_lessons_by_query($query) {
    global $pagenow;
    
    if (!is_admin() || $pagenow !== 'edit.php') {
        return;
    }
    
    if (!isset($query->query_vars['post_type']) || $query->query_vars['post_type'] !== 'farsi_lesson') {
        return;
    }
    
    // Filter by instructor
    if (isset($_GET['filter_instructor']) && !empty($_GET['filter_instructor'])) {
        $query->query_vars['author'] = intval($_GET['filter_instructor']);
    }
    
    // Search by title
    if (isset($_GET['search_lesson_title']) && !empty($_GET['search_lesson_title'])) {
        $query->query_vars['s'] = sanitize_text_field($_GET['search_lesson_title']);
    }
}

/* ==========================================================================
   CUSTOM COLUMNS FOR LESSON LIST
   ========================================================================== */

add_filter('manage_farsi_lesson_posts_columns', 'flm_lesson_columns');
function flm_lesson_columns($columns) {
    // Remove date, add our custom columns
    unset($columns['date']);
    
    $new_columns = array();
    $new_columns['cb'] = $columns['cb'];
    $new_columns['title'] = $columns['title'];
    $new_columns['instructor'] = 'Instructor';
    $new_columns['notes'] = 'Notes';
    $new_columns['student_file'] = 'Student File';
    $new_columns['teacher_file'] = 'Teacher File';
    $new_columns['date'] = 'Date';
    
    return $new_columns;
}

add_action('manage_farsi_lesson_posts_custom_column', 'flm_lesson_column_content', 10, 2);
function flm_lesson_column_content($column, $post_id) {
    switch ($column) {
        case 'instructor':
            $author_id = get_post_field('post_author', $post_id);
            $author = get_user_by('id', $author_id);
            echo $author ? esc_html($author->display_name) : 'Unknown';
            break;
            
        case 'notes':
            $notes = get_post_meta($post_id, '_flm_notes', true);
            if ($notes) {
                echo '<span style="color: #666; font-style: italic;">' . esc_html(wp_trim_words($notes, 8)) . '</span>';
            } else {
                echo '<span style="color: #999;">—</span>';
            }
            break;
            
        case 'student_file':
            $file_id = get_post_meta($post_id, '_flm_student_file', true);
            if ($file_id) {
                $file_url = wp_get_attachment_url($file_id);
                echo '<a href="' . esc_url($file_url) . '" target="_blank" title="Download">📄</a>';
            } else {
                echo '<span style="color: #999;">—</span>';
            }
            break;
            
        case 'teacher_file':
            $file_id = get_post_meta($post_id, '_flm_teacher_file', true);
            if ($file_id) {
                $file_url = wp_get_attachment_url($file_id);
                echo '<a href="' . esc_url($file_url) . '" target="_blank" title="Download">📄</a>';
            } else {
                echo '<span style="color: #999;">—</span>';
            }
            break;
    }
}

/* ==========================================================================
   MAKE COLUMNS SORTABLE
   ========================================================================== */

add_filter('manage_edit-farsi_lesson_sortable_columns', 'flm_lesson_sortable_columns');
function flm_lesson_sortable_columns($columns) {
    $columns['instructor'] = 'author';
    return $columns;
}
