<?php
/**
 * AJAX Fresh Lesson Loader
 * Returns lessons directly from database - bypasses ALL cache!
 */

if (!defined('ABSPATH')) exit;

/* ==========================================================================
   AJAX HANDLER - Get Fresh Lessons (No Cache!)
   ========================================================================== */

add_action('wp_ajax_flm_get_fresh_lessons', 'flm_ajax_get_fresh_lessons');
add_action('wp_ajax_nopriv_flm_get_fresh_lessons', 'flm_ajax_get_fresh_lessons');
function flm_ajax_get_fresh_lessons() {
    
    // Check nonce
    if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'flm_admin_nonce')) {
        wp_send_json_error(array('message' => 'Security check failed.'));
    }
    
    // MODIFIED: Use the explicit list_type POST variable for reliable filtering
    $list_type = isset($_POST['list_type']) ? sanitize_text_field($_POST['list_type']) : 'all-lessons';
    $show_all = ($list_type !== 'my-lessons');
    $current_user_id = get_current_user_id();
    
    // Build query args
    $args = array(
        'post_type' => 'farsi_lesson',
        'posts_per_page' => -1,
        'orderby' => 'title',
        'order' => 'ASC',
        'post_status' => 'publish',
        'no_found_rows' => true, // Performance optimization
        'update_post_meta_cache' => true,
        'update_post_term_cache' => false, // Performance optimization
    );
    
    // Filter by author if needed
    if (!$show_all && $current_user_id) {
        $args['author'] = $current_user_id;
    }
    
    // Get lessons FRESH from database
    $lessons = get_posts($args);
    
    if (empty($lessons)) {
        // MODIFIED: Return empty HTML. JS will handle the "No lessons" message.
        wp_send_json_success(array(
            'count' => 0,
            'html' => ''
        ));
    }
    
    // Build HTML
    $can_view_dashboard = current_user_can('edit_posts');
    $delete_nonce = wp_create_nonce('flm_delete_lesson');
    
    ob_start();
    
    foreach ($lessons as $lesson) {
        $notes = get_post_meta($lesson->ID, '_flm_notes', true);
        $author = get_user_by('id', $lesson->post_author);
        
        $is_author = ($current_user_id == $lesson->post_author);
        $can_delete = flm_can_delete_lesson($lesson->ID);
        $can_edit = flm_can_edit_lesson($lesson->ID);
        ?>
        <tr data-lesson-id="<?php echo $lesson->ID; ?>" 
            data-search-title="<?php echo esc_attr(strtolower($lesson->post_title)); ?>"
            data-search-instructor="<?php echo $author ? esc_attr(strtolower($author->display_name)) : ''; ?>"
            data-search-notes="<?php echo esc_attr(strtolower($notes)); ?>">
            <td><div class="flm-title-text"><?php echo esc_html($lesson->post_title); ?></div></td>
            <td><div class="flm-instructor-text"><?php echo $author ? esc_html($author->display_name) : 'Unknown'; ?></div></td>
            <td>
                <a href="<?php echo get_permalink($lesson->ID); ?>" class="flm-btn flm-btn-view" target="_blank" title="View Lesson">
                    <i class="fas fa-eye"></i>
                </a>
            </td>
            <?php if ($can_view_dashboard) : ?>
            <td class="flm-notes-cell">
                <div class="flm-notes-display">
                    <div class="flm-notes-content">
                        <?php echo $notes ? esc_html($notes) : '<em style="color:#999;">No notes</em>'; ?>
                    </div>
                    <?php if ($can_edit) : ?>
                    <button class="flm-btn flm-btn-edit-note" data-lesson-id="<?php echo $lesson->ID; ?>" data-can-edit="true" title="Edit Notes">
                        <i class="fas fa-pen"></i>
                    </button>
                    <?php else : ?>
                    <button class="flm-btn flm-btn-edit-note disabled" disabled title="You cannot edit this note">
                        <i class="fas fa-lock"></i>
                    </button>
                    <?php endif; ?>
                </div>
                <?php if ($can_edit) : ?>
                <div class="flm-notes-edit" style="display:none;">
                    <textarea class="flm-notes-textarea" rows="2"><?php echo esc_textarea($notes); ?></textarea>
                    <div class="flm-notes-buttons">
                        <button class="flm-btn-save-note" data-lesson-id="<?php echo $lesson->ID; ?>">Save</button>
                        <button class="flm-btn-cancel-note">Cancel</button>
                    </div>
                </div>
                <?php endif; ?>
            </td>
            <td style="white-space: nowrap;">
                <?php if ($can_edit) : ?>
                    <a href="<?php echo admin_url('post.php?post=' . $lesson->ID . '&action=edit'); ?>" class="flm-btn flm-btn-edit" title="Edit Lesson">
                        <i class="fas fa-pen"></i>
                    </a>
                <?php else : ?>
                    <button class="flm-btn flm-btn-edit disabled" disabled title="You cannot edit this lesson">
                        <i class="fas fa-lock"></i>
                    </button>
                <?php endif; ?>
                
                <?php if ($can_delete) : ?>
                    <button class="flm-btn flm-btn-delete" data-lesson-id="<?php echo $lesson->ID; ?>" title="Delete Lesson">
                        <i class="fas fa-trash"></i>
                    </button>
                <?php else : ?>
                    <button class="flm-btn flm-btn-delete disabled" disabled title="You cannot delete this lesson">
                        <i class="fas fa-lock"></i>
                    </button>
                <?php endif; ?>
            </td>
            <?php endif; ?>
        </tr>
        <?php
    }
    
    $html = ob_get_clean();
    
    wp_send_json_success(array(
        'count' => count($lessons),
        'html' => $html
    ));
}