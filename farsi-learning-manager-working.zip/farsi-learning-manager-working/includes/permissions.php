<?php
/**
 * Permission Checks
 */

if (!defined('ABSPATH')) exit;

// Check if user can edit lesson
function flm_can_edit_lesson($lesson_id) {
    if (!is_user_logged_in()) {
        return false;
    }
    
    $current_user = wp_get_current_user();
    $lesson = get_post($lesson_id);
    
    if (!$lesson || $lesson->post_type !== 'farsi_lesson') {
        return false;
    }
    
    // Admin and Team Leader can edit everything
    if (in_array('administrator', $current_user->roles) || in_array('flm_team_leader', $current_user->roles)) {
        return true;
    }
    
    // Chairperson can edit all
    if (in_array('flm_chairperson', $current_user->roles)) {
        return true;
    }
    
    // Instructor can only edit their own
    if (in_array('flm_instructor', $current_user->roles)) {
        return $lesson->post_author == $current_user->ID;
    }
    
    return false;
}

// Check if user can delete lesson
function flm_can_delete_lesson($lesson_id) {
    if (!is_user_logged_in()) {
        return false;
    }
    
    $current_user = wp_get_current_user();
    $lesson = get_post($lesson_id);
    
    if (!$lesson || $lesson->post_type !== 'farsi_lesson') {
        return false;
    }
    
    // Admin and Team Leader can delete everything
    if (in_array('administrator', $current_user->roles) || in_array('flm_team_leader', $current_user->roles)) {
        return true;
    }
    
    // Instructor can only delete their own
    if (in_array('flm_instructor', $current_user->roles)) {
        return $lesson->post_author == $current_user->ID;
    }
    
    return false;
}

// Check if user is admin or editor role
function flm_is_admin_or_editor() {
    if (!is_user_logged_in()) {
        return false;
    }
    
    $current_user = wp_get_current_user();
    return in_array('administrator', $current_user->roles) || 
           in_array('editor', $current_user->roles) ||
           in_array('flm_team_leader', $current_user->roles) ||
           in_array('flm_chairperson', $current_user->roles);
}
