<?php
/**
 * Two-Factor Authentication System
 */

if (!defined('ABSPATH')) exit;

define('FLM_2FA_ENABLED', true);
define('FLM_2FA_CODE_EXPIRY', 10);
define('FLM_2FA_TRUST_DAYS', 30);

/* ==========================================================================
   SHORTCODE WITH URL TOKEN SUPPORT
   ========================================================================== */

add_shortcode('farsi_2fa_verify', 'flm_2fa_verify_shortcode');
function flm_2fa_verify_shortcode() {
    
    $user_id = 0;

    // 1. Try finding User ID in Cookie
    if (isset($_COOKIE['flm_2fa_pending'])) {
        $user_id = (int)$_COOKIE['flm_2fa_pending'];
    } 
    // 2. Fallback: Try finding User ID in URL (Secure Token)
    elseif (isset($_GET['uid']) && isset($_GET['t'])) {
        $uid = (int)$_GET['uid'];
        $token = $_GET['t'];
        // Verify the token matches the ID
        if (wp_hash($uid . 'flm_2fa_fallback') === $token) {
            $user_id = $uid;
        }
    }

    // If neither worked, show error
    if (!$user_id) {
        ?>
        <div class="flm-login-wrapper">
            <div class="flm-login-container" style="text-align: center;">
                <div style="font-size: 48px; color: #dc3545; margin-bottom: 20px;">
                    <i class="fas fa-exclamation-circle"></i>
                </div>
                <h3>Session Expired</h3>
                <p>We could not verify your identity. Please try logging in again.</p>
                <a href="<?php echo home_url('/login/'); ?>" class="flm-login-btn" style="text-decoration:none; display:inline-block;">Back to Login</a>
            </div>
        </div>
        <?php
        return;
    }
    
    $user = get_user_by('id', $user_id);
    if (!$user) {
        echo '<script>window.location.href="'.home_url('/login/').'";</script>';
        return;
    }
    
    ob_start();
    ?>
    
    <div class="flm-login-wrapper">
        <div class="flm-login-container">
            <div class="flm-login-logo">
                <img src="<?php echo esc_url(home_url('/wp-content/uploads/2025/12/logo-admin.png')); ?>" alt="Logo">
            </div>
            
            <div style="text-align: center; margin-bottom: 30px;">
                <div style="font-size: 48px; color: #2271b1; margin-bottom: 15px;">
                    <i class="fas fa-shield-alt"></i>
                </div>
                <h2>Two-Factor Authentication</h2>
                <p style="color: #666; font-size: 14px;">
                    Enter the code sent to: <strong><?php echo esc_html($user->user_email); ?></strong>
                </p>
            </div>
            
            <form id="flm-2fa-form" method="post">
                <?php wp_nonce_field('flm_2fa_verify', 'flm_2fa_nonce'); ?>
                
                <input type="hidden" name="user_id" value="<?php echo esc_attr($user_id); ?>">
                
                <div class="flm-login-field">
                    <input type="text" name="verification_code" id="flm-verification-code" required placeholder="000000" maxlength="6" pattern="[0-9]{6}" autocomplete="off" style="text-align: center; font-size: 24px; letter-spacing: 5px;">
                </div>
                
                <div class="flm-login-remember">
                    <label><input type="checkbox" name="trust_device" value="1"> <span>Trust this device (30 days)</span></label>
                </div>
                
                <button type="submit" class="flm-login-btn" id="flm-2fa-submit">
                    <span class="flm-login-btn-text">Verify</span>
                </button>
                <div id="flm-2fa-message" class="flm-login-message" style="display:none;"></div>
                
                <div style="text-align: center; margin-top: 20px;">
                    <button type="button" id="flm-resend-code" style="background:none; border:none; color:#2271b1; text-decoration:underline; cursor:pointer;">Resend Code</button>
                </div>
            </form>
            <div class="flm-login-footer"><a href="<?php echo home_url('/login/'); ?>">Back to Login</a></div>
        </div>
    </div>
    <?php
    return ob_get_clean();
}

/* ==========================================================================
   2FA LOGIC
   ========================================================================== */

function flm_generate_2fa_code($user_id) {
    $code = str_pad(rand(0, 999999), 6, '0', STR_PAD_LEFT);
    update_user_meta($user_id, 'flm_2fa_code', $code);
    update_user_meta($user_id, 'flm_2fa_expiry', time() + (FLM_2FA_CODE_EXPIRY * 60));
    update_user_meta($user_id, 'flm_2fa_attempts', 0);
    return $code;
}

function flm_send_2fa_code($user_id) {
    $user = get_user_by('id', $user_id);
    if (!$user) return false;
    
    $code = flm_generate_2fa_code($user_id);
    $site = get_bloginfo('name');
    $msg = "Your login code is: $code\n\nExpires in 10 minutes.\n\n$site";
    
    return wp_mail($user->user_email, "[$site] Verification Code", $msg);
}

function flm_verify_2fa_code($user_id, $code) {
    $stored = get_user_meta($user_id, 'flm_2fa_code', true);
    $expiry = get_user_meta($user_id, 'flm_2fa_expiry', true);
    
    if (time() > $expiry) return array('success' => false, 'message' => 'Code expired.');
    if ($code !== $stored) return array('success' => false, 'message' => 'Invalid code.');
    
    delete_user_meta($user_id, 'flm_2fa_code');
    delete_user_meta($user_id, 'flm_2fa_expiry');
    return array('success' => true);
}

function flm_is_device_trusted($user_id) {
    if (!isset($_COOKIE['flm_trusted_device_' . $user_id])) return false;
    $token = $_COOKIE['flm_trusted_device_' . $user_id];
    $stored = get_user_meta($user_id, 'flm_trusted_device_token', true);
    return ($token === $stored && time() < get_user_meta($user_id, 'flm_trusted_device_expiry', true));
}

function flm_trust_device($user_id) {
    $token = wp_generate_password(32, false);
    $expiry = time() + (FLM_2FA_TRUST_DAYS * 86400);
    update_user_meta($user_id, 'flm_trusted_device_token', $token);
    update_user_meta($user_id, 'flm_trusted_device_expiry', $expiry);
    setcookie('flm_trusted_device_' . $user_id, $token, $expiry, '/');
}

// AJAX: VERIFY
add_action('wp_ajax_nopriv_flm_verify_2fa', 'flm_ajax_verify_2fa');
function flm_ajax_verify_2fa() {
    check_ajax_referer('flm_2fa_verify', 'flm_2fa_nonce');
    
    $user_id = 0;
    
    // Identify user via Cookie OR Hidden Form Field
    if (isset($_COOKIE['flm_2fa_pending'])) {
        $user_id = (int)$_COOKIE['flm_2fa_pending'];
    } elseif (isset($_POST['user_id'])) {
        $user_id = (int)$_POST['user_id'];
    }
    
    if (!$user_id) wp_send_json_error(array('message' => 'Session expired.'));
    
    // Verify Logic
    $res = flm_verify_2fa_code($user_id, $_POST['verification_code']);
    
    if (!$res['success']) wp_send_json_error($res);
    
    // Success: Log them in
    wp_set_current_user($user_id);
    wp_set_auth_cookie($user_id, isset($_COOKIE['flm_remember_me']));
    
    if (isset($_POST['trust_device']) && $_POST['trust_device'] == '1') flm_trust_device($user_id);
    
    // Clean up
    setcookie('flm_2fa_pending', '', time() - 3600, '/');
    
    $redirect = home_url('/my-dashboard/');
    if (isset($_COOKIE['flm_redirect_after_login'])) {
        $redirect = $_COOKIE['flm_redirect_after_login'];
        setcookie('flm_redirect_after_login', '', time() - 3600, '/');
    }
    
    wp_send_json_success(array('message' => 'Success!', 'redirect' => $redirect));
}

// AJAX: RESEND
add_action('wp_ajax_nopriv_flm_resend_2fa', 'flm_ajax_resend_2fa');
function flm_ajax_resend_2fa() {
    $user_id = 0;
    if (isset($_COOKIE['flm_2fa_pending'])) {
        $user_id = (int)$_COOKIE['flm_2fa_pending'];
    } elseif (isset($_POST['user_id'])) { // We would need to update the JS to send this too, but for resend, cookie usually exists by then
         $user_id = (int)$_POST['user_id'];
    }
    
    if (!$user_id) wp_send_json_error(array('message' => 'Session expired.'));
    
    if (flm_send_2fa_code($user_id)) wp_send_json_success(array('message' => 'Code sent.'));
    else wp_send_json_error(array('message' => 'Error sending code.'));
}