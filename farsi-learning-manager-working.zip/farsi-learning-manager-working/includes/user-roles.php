<?php
/**
 * Custom User Roles
 */

if (!defined('ABSPATH')) exit;

// Create custom roles
function flm_create_custom_roles() {
    
    // Team Leader - Can manage all lessons and instructors
    add_role('flm_team_leader', 'Team Leader', array(
        'read' => true,
        'edit_posts' => true,
        'delete_posts' => true,
        'publish_posts' => true,
        'upload_files' => true,
        'edit_others_posts' => true,
        'delete_others_posts' => true,
        'edit_published_posts' => true,
        'delete_published_posts' => true,
        'manage_categories' => true,
    ));
    
    // Chairperson - Can review and approve materials
    add_role('flm_chairperson', 'Chairperson', array(
        'read' => true,
        'edit_posts' => true,
        'delete_posts' => true,
        'publish_posts' => true,
        'upload_files' => true,
        'edit_others_posts' => true,
        'edit_published_posts' => true,
    ));
    
    // Instructor - Can add materials, edit/delete only their own
    add_role('flm_instructor', 'Instructor', array(
        'read' => true,
        'edit_posts' => true,
        'delete_posts' => true,
        'publish_posts' => true,
        'upload_files' => true,
        'edit_published_posts' => true,
        'delete_published_posts' => true,
    ));
    
    // Add capabilities to admin
    $admin = get_role('administrator');
    if ($admin) {
        $admin->add_cap('manage_farsi_lessons');
    }
}

// Add custom capabilities to post type
add_filter('map_meta_cap', 'flm_map_meta_caps', 10, 4);
function flm_map_meta_caps($caps, $cap, $user_id, $args) {
    
    if ($cap !== 'edit_post' && $cap !== 'delete_post') {
        return $caps;
    }
    
    if (empty($args[0])) {
        return $caps;
    }
    
    $post = get_post($args[0]);
    
    if (!$post || $post->post_type !== 'farsi_lesson') {
        return $caps;
    }
    
    $user = get_userdata($user_id);
    
    // Admin and Team Leader can edit/delete everything
    if (in_array('administrator', $user->roles) || in_array('flm_team_leader', $user->roles)) {
        return array('edit_posts');
    }
    
    // Chairperson can edit but not delete others' posts
    if (in_array('flm_chairperson', $user->roles)) {
        if ($cap === 'delete_post' && $post->post_author != $user_id) {
            return array('do_not_allow');
        }
        return array('edit_posts');
    }
    
    // Instructor can only edit/delete their own posts
    if (in_array('flm_instructor', $user->roles)) {
        if ($post->post_author == $user_id) {
            return array('edit_posts');
        }
        return array('do_not_allow');
    }
    
    return $caps;
}
