<?php
/**
 * AJAX Handlers - GENERAL SUBMISSION (NO LESSON ID REQUIRED)
 */

if (!defined('ABSPATH')) exit;

// FALLBACK: Ensure FLM_PLUGIN_PATH is defined for relative includes within AJAX functions
if (!defined('FLM_PLUGIN_PATH')) {
    define('FLM_PLUGIN_PATH', plugin_dir_path(dirname(dirname(__FILE__))) . 'farsi-learning-manager-working/');
}

/* ==========================
   HELPER: FIND LESSON BY ID EMBEDDED IN FILENAME
   ========================== */

/**
 * Attempts to find a farsi_lesson post ID using the submitted filename.
 * It assumes the filename is prefixed with the Lesson ID based on the new upload logic.
 * E.g., a file named "123-LessonName.pdf" will return ID 123.
 * * @param string $submitted_filename The name of the first uploaded file.
 * @return int The lesson ID if found and valid, 0 otherwise.
 */
function flm_find_lesson_by_submission($submitted_filename) {
    if (empty($submitted_filename)) {
        return 0;
    }

    // Attempt to extract the leading post ID from the filename.
    if (preg_match('/^(\d+)[-_]/', basename($submitted_filename), $matches)) {
        $lesson_id = intval($matches[1]);

        // Validate that the extracted ID is actually a farsi_lesson post
        if ($lesson_id > 0 && get_post_type($lesson_id) === 'farsi_lesson') {
            return $lesson_id;
        }
    }

    return 0;
}


/* ==========================
   INSTRUCTOR LESSON UPLOAD
   ========================== */

add_action('wp_ajax_flm_instructor_upload', 'flm_instructor_upload');
function flm_instructor_upload() {
    
    if (!isset($_POST['flm_instructor_nonce']) || !wp_verify_nonce($_POST['flm_instructor_nonce'], 'flm_instructor_upload')) {
        wp_send_json_error(array('message' => 'Security check failed.'));
    }
    
    if (!is_user_logged_in() || !current_user_can('edit_posts')) {
        wp_send_json_error(array('message' => 'Permission denied.'));
    }
    
    $lesson_title = sanitize_text_field($_POST['lesson_title']);
    $lesson_notes = sanitize_textarea_field($_POST['lesson_notes']);
    
    if (empty($lesson_title)) {
        wp_send_json_error(array('message' => 'Please enter a lesson title.'));
    }
    
    // Check if student file is uploaded
    if (empty($_FILES['student_file']['name'])) {
        wp_send_json_error(array('message' => 'Please upload a student file.'));
    }
    
    // 1. Create lesson post first to get the ID
    $lesson_id = wp_insert_post(array(
        'post_type' => 'farsi_lesson',
        'post_title' => $lesson_title,
        'post_status' => 'publish',
        'post_author' => get_current_user_id()
    ));
    
    if (is_wp_error($lesson_id)) {
        wp_send_json_error(array('message' => 'Failed to create lesson.'));
    }
    
    // Save notes
    if (!empty($lesson_notes)) {
        update_post_meta($lesson_id, '_flm_notes', $lesson_notes);
    }
    
    // Handle file uploads
    require_once(ABSPATH . 'wp-admin/includes/file.php');
    require_once(ABSPATH . 'wp-admin/includes/media.php');
    require_once(ABSPATH . 'wp-admin/includes/image.php');
    
    $lesson_id_prefix = $lesson_id . '-';
    
    // 2. Upload student file (Required)
    if (!empty($_FILES['student_file']['name'])) {
        $student_file = $_FILES['student_file'];
        
        // Validate file type
        $allowed_types = array('application/pdf', 'application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document');
        $finfo = finfo_open(FILEINFO_MIME_TYPE);
        $mime = finfo_file($finfo, $student_file['tmp_name']);
        finfo_close($finfo);
        
        if (!in_array($mime, $allowed_types)) {
            wp_delete_post($lesson_id, true);
            wp_send_json_error(array('message' => 'Student file must be PDF or Word document.'));
        }
        
        $upload = wp_handle_upload($student_file, array('test_form' => false));
        
        if (isset($upload['error'])) {
            wp_delete_post($lesson_id, true);
            wp_send_json_error(array('message' => 'Student file upload failed: ' . $upload['error']));
        }
        
        // START NEW RENAME LOGIC
        $original_path = $upload['file'];
        $original_filename = basename($original_path);
        $new_filename = $lesson_id_prefix . $original_filename;
        $new_path = str_replace($original_filename, $new_filename, $original_path);
        
        if (!rename($original_path, $new_path)) {
            // If rename fails, abort lesson creation as we can't guarantee the ID is in the name
            wp_delete_post($lesson_id, true);
            wp_send_json_error(array('message' => 'Failed to rename student file after upload. File permission error?'));
        }
        
        // Update variables after successful rename
        $upload['file'] = $new_path;
        // END NEW RENAME LOGIC

        // Create attachment (using updated $upload['file'] path)
        $attachment_id = wp_insert_attachment(array(
            'post_mime_type' => $upload['type'],
            'post_title' => sanitize_file_name($new_filename), 
            'post_content' => '',
            'post_status' => 'inherit'
        ), $upload['file'], $lesson_id);
        
        if (!is_wp_error($attachment_id)) {
            $attach_data = wp_generate_attachment_metadata($attachment_id, $upload['file']);
            wp_update_attachment_metadata($attachment_id, $attach_data);
            update_post_meta($lesson_id, '_flm_student_file', $attachment_id);
        }
    }
    
    // 3. Upload teacher file (Optional)
    if (!empty($_FILES['teacher_file']['name'])) {
        $teacher_file = $_FILES['teacher_file'];
        
        $allowed_types = array('application/pdf', 'application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document');
        $finfo = finfo_open(FILEINFO_MIME_TYPE);
        $mime = finfo_file($finfo, $teacher_file['tmp_name']);
        finfo_close($finfo);
        
        if (in_array($mime, $allowed_types)) {
            $upload = wp_handle_upload($teacher_file, array('test_form' => false));
            
            if (!isset($upload['error'])) {
                // START NEW RENAME LOGIC
                $original_path = $upload['file'];
                $original_filename = basename($original_path);
                $new_filename = $lesson_id_prefix . $original_filename;
                $new_path = str_replace($original_filename, $new_filename, $original_path);
                
                if (rename($original_path, $new_path)) {
                    $upload['file'] = $new_path;
                } else {
                    $new_filename = $original_filename; // Keep original filename if rename fails
                }
                // END NEW RENAME LOGIC
                
                $attachment_id = wp_insert_attachment(array(
                    'post_mime_type' => $upload['type'],
                    'post_title' => sanitize_file_name($new_filename),
                    'post_content' => '',
                    'post_status' => 'inherit'
                ), $upload['file'], $lesson_id);
                
                if (!is_wp_error($attachment_id)) {
                    $attach_data = wp_generate_attachment_metadata($attachment_id, $upload['file']);
                    wp_update_attachment_metadata($attachment_id, $attach_data);
                    update_post_meta($lesson_id, '_flm_teacher_file', $attachment_id);
                }
            }
        }
    }
    
    // 4. Upload audio file (Optional)
    if (!empty($_FILES['audio_file']['name'])) {
        $audio_file = $_FILES['audio_file'];
        
        $allowed_types = array('audio/mpeg', 'audio/mp3', 'audio/wav');
        $finfo = finfo_open(FILEINFO_MIME_TYPE);
        $mime = finfo_file($finfo, $audio_file['tmp_name']);
        finfo_close($finfo);
        
        if (in_array($mime, $allowed_types)) {
            $upload = wp_handle_upload($audio_file, array('test_form' => false));
            
            if (!isset($upload['error'])) {
                // START NEW RENAME LOGIC
                $original_path = $upload['file'];
                $original_filename = basename($original_path);
                $new_filename = $lesson_id_prefix . $original_filename;
                $new_path = str_replace($original_filename, $new_filename, $original_path);
                
                if (rename($original_path, $new_path)) {
                    $upload['file'] = $new_path;
                } else {
                    $new_filename = $original_filename; // Keep original filename if rename fails
                }
                // END NEW RENAME LOGIC
                
                $attachment_id = wp_insert_attachment(array(
                    'post_mime_type' => $upload['type'],
                    'post_title' => sanitize_file_name($new_filename),
                    'post_content' => '',
                    'post_status' => 'inherit'
                ), $upload['file'], $lesson_id);
                
                if (!is_wp_error($attachment_id)) {
                    $attach_data = wp_generate_attachment_metadata($attachment_id, $upload['file']);
                    wp_update_attachment_metadata($attachment_id, $attach_data);
                    update_post_meta($lesson_id, '_flm_audio_file', $attachment_id);
                }
            }
        }
    }
    
    wp_send_json_success(array(
        'message' => 'Lesson created successfully! Note: All files have been renamed to include Lesson ID: ' . $lesson_id,
        'redirect' => home_url('/my-dashboard/')
    ));
}

/* ==========================
   GENERAL SUBMISSION HANDLER
   ========================== */

add_action('wp_ajax_flm_validate_security_code', 'flm_validate_security_code');
add_action('wp_ajax_nopriv_flm_validate_security_code', 'flm_validate_security_code');
function flm_validate_security_code() {
    
    if (!isset($_POST['code'])) {
        wp_send_json_error(array('message' => 'No code provided.'));
    }
    
    $entered_code = sanitize_text_field($_POST['code']);
    
    // Empty code = invalid
    if (empty($entered_code)) {
        wp_send_json_error(array('message' => 'Please enter a security code.'));
    }
    
    // Check against valid codes
    $valid_codes = get_option('flm_security_codes', array());
    
    foreach ($valid_codes as $code_data) {
        if ($code_data['code'] === $entered_code) {
            wp_send_json_success(array('message' => 'Valid code!'));
        }
    }
    
    wp_send_json_error(array('message' => 'Invalid security code.'));
}

add_action('wp_ajax_flm_submit_work', 'flm_handle_submission');
add_action('wp_ajax_nopriv_flm_submit_work', 'flm_handle_submission');
function flm_handle_submission() {
    
    if (!isset($_POST['flm_nonce']) || !wp_verify_nonce($_POST['flm_nonce'], 'flm_submit_work')) {
        wp_send_json_error(array('message' => 'Security check failed.'));
    }
    
    // Validate required fields
    if (empty($_POST['student_email']) || empty($_POST['mentor_email']) || empty($_POST['security_code']) || empty($_POST['subject'])) {
        wp_send_json_error(array('message' => 'Please fill in all required fields.'));
    }
    
    $student_email = sanitize_email($_POST['student_email']);
    $mentor_email = sanitize_email($_POST['mentor_email']);
    $subject = sanitize_text_field($_POST['subject']);
    $notes = isset($_POST['notes']) ? sanitize_textarea_field($_POST['notes']) : '';
    
    if (!is_email($student_email) || !is_email($mentor_email)) {
        wp_send_json_error(array('message' => 'Please enter valid email addresses.'));
    }
    
    // Validate security code
    $entered_code = sanitize_text_field($_POST['security_code']);
    $valid_codes = get_option('flm_security_codes', array());
    
    $code_valid = false;
    foreach ($valid_codes as $code_data) {
        if ($code_data['code'] === $entered_code) {
            $code_valid = true;
            break;
        }
    }
    
    if (!$code_valid) {
        wp_send_json_error(array('message' => 'Invalid security code. Please contact your administrator.'));
    }
    
    if (!isset($_FILES['submission_files']) || empty($_FILES['submission_files']['name'][0])) {
        wp_send_json_error(array('message' => 'Please upload at least one file.'));
    }
    
    // Prepare upload directory
    $upload_dir = wp_upload_dir();
    $flm_dir = $upload_dir['basedir'] . '/flm-submissions/' . date('Y/m');
    
    if (!file_exists($flm_dir)) {
        wp_mkdir_p($flm_dir);
    }
    
    // Process uploaded files
    $uploaded_files = array();
    $files = $_FILES['submission_files'];
    $first_uploaded_file_name = ''; // Capture the name of the first file
    
    for ($i = 0; $i < count($files['name']); $i++) {
        if ($files['error'][$i] === UPLOAD_ERR_NO_FILE) continue;
        
        $finfo = finfo_open(FILEINFO_MIME_TYPE);
        $mime = finfo_file($finfo, $files['tmp_name'][$i]);
        finfo_close($finfo);
        
        $allowed = array('application/pdf', 'application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document');
        if (!in_array($mime, $allowed)) {
            wp_send_json_error(array('message' => 'Invalid file type. Only PDF and Word documents are allowed.'));
        }
        
        if ($files['size'][$i] > 10485760) {
            wp_send_json_error(array('message' => 'File is too large. Maximum size is 10MB per file.'));
        }
        
        $timestamp = time();
        $random = wp_generate_password(8, false);
        $extension = pathinfo($files['name'][$i], PATHINFO_EXTENSION);
        $filename = 'submission_' . $timestamp . '_' . $random . '.' . $extension;
        $destination = $flm_dir . '/' . $filename;
        
        if (!move_uploaded_file($files['tmp_name'][$i], $destination)) {
            wp_send_json_error(array('message' => 'Failed to save file. Please try again.'));
        }
        
        $sanitized_filename = sanitize_file_name($files['name'][$i]);
        
        if ($i === 0) {
             $first_uploaded_file_name = $sanitized_filename; // Store the first file's name
        }
        
        $uploaded_files[] = array(
            'name' => $sanitized_filename,
            'path' => str_replace($upload_dir['basedir'], $upload_dir['baseurl'], $destination)
        );
    }
    
    // Create submission post
    $submission_id = wp_insert_post(array(
        'post_type' => 'farsi_submission',
        'post_title' => $student_email . ' - ' . $subject,
        'post_status' => 'publish',
    ));
    
    if (is_wp_error($submission_id)) {
        wp_send_json_error(array('message' => 'Failed to save submission.'));
    }
    
    // Save meta data
    update_post_meta($submission_id, '_flm_student_email', $student_email);
    update_post_meta($submission_id, '_flm_mentor_email', $mentor_email);
    update_post_meta($submission_id, '_flm_subject', $subject);
    update_post_meta($submission_id, '_flm_notes', $notes);
    update_post_meta($submission_id, '_flm_files', json_encode($uploaded_files));
    update_post_meta($submission_id, '_flm_submission_date', current_time('mysql'));
    
    
    // ======================================================================
    // LOGIC TO FIND LESSON AND GET TEACHER FILE URL
    // ======================================================================
    $teacher_file_url = null;
    $found_lesson_id = 0;
    
    // Use the explicit ID extraction function
    $found_lesson_id = flm_find_lesson_by_submission($first_uploaded_file_name);

    if ($found_lesson_id) {
        // Save the Lesson ID to the submission meta for admin reference
        update_post_meta($submission_id, '_flm_lesson_id', $found_lesson_id);
        
        $teacher_file_id = get_post_meta($found_lesson_id, '_flm_teacher_file', true);
        if ($teacher_file_id) {
            $teacher_file_url = wp_get_attachment_url($teacher_file_id);
        }
    }
    // ======================================================================
    
    
    // Send notification email to mentor
    $site_name = get_bloginfo('name');
    $mentor_subject = "[$site_name] New Submission: " . $subject;
    $mentor_message = "New submission received.\n\n";
    $mentor_message .= "Student Email: $student_email\n";
    $mentor_message .= "Subject: $subject\n";
    $mentor_message .= "Submission Time: " . current_time('mysql') . "\n\n";
    
    if (!empty($notes)) {
        $mentor_message .= "Student Notes:\n$notes\n\n";
    }
    
    $mentor_message .= "Submitted Files:\n";
    foreach ($uploaded_files as $file) {
        $mentor_message .= "- " . $file['name'] . "\n  Download: " . $file['path'] . "\n\n";
    }
    $mentor_message .= "\nView submission in admin: " . admin_url('post.php?post=' . $submission_id . '&action=edit');
    
    wp_mail($mentor_email, $mentor_subject, $mentor_message, array('Content-Type: text/plain; charset=UTF-8'));
    
    // Send copy to admin email
    $admin_email = get_option('admin_email');
    if ($admin_email && $admin_email !== $mentor_email) {
        wp_mail($admin_email, $mentor_subject, $mentor_message, array('Content-Type: text/plain; charset=UTF-8'));
    }
    
    // Send confirmation to student
    $student_subject = "[$site_name] Submission Received - " . $subject;
    $student_message = "Hello,\n\nYour submission for \"$subject\" has been received successfully.\n\n";
    $student_message .= "Your mentor ($mentor_email) has been notified and will review your work.\n\n";
    
    // Append Teacher File link to student email
    if ($teacher_file_url) {
        $student_message .= "You can download the **Teacher's Copy / Answer Key** here:\n";
        $student_message .= "$teacher_file_url\n\n";
        $student_message .= "Please use this copy for self-review while awaiting feedback.\n\n";
    }
    
    $student_message .= "Thank you!\n\n$site_name";
    
    wp_mail($student_email, $student_subject, $student_message, array('Content-Type: text/plain; charset=UTF-8'));
    
    wp_send_json_success(array('message' => 'Your submission was received successfully! Check your email for confirmation.'));
}

/* ==========================
   NOTES SAVE HANDLER
   ========================== */

add_action('wp_ajax_flm_save_notes', 'flm_save_notes_ajax');
function flm_save_notes_ajax() {
    if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'flm_admin_nonce')) {
        wp_send_json_error(array('message' => 'Security check failed.'));
    }
    
    $lesson_id = intval($_POST['lesson_id']);
    $notes = sanitize_textarea_field($_POST['notes']);
    
    if (!$lesson_id || get_post_type($lesson_id) !== 'farsi_lesson') {
        wp_send_json_error(array('message' => 'Invalid lesson.'));
    }
    
    if (!flm_can_edit_lesson($lesson_id)) {
        wp_send_json_error(array('message' => 'Permission denied. You can only edit your own notes.'));
    }
    
    update_post_meta($lesson_id, '_flm_notes', $notes);
    
    wp_send_json_success(array(
        'message' => 'Notes saved successfully.',
        'notes' => $notes
    ));
}

/* ==========================
   FILE UPDATE HANDLER
   ========================== */

add_action('wp_ajax_flm_update_file', 'flm_update_file_ajax');
function flm_update_file_ajax() {
    $lesson_id = intval($_POST['lesson_id']);
    $file_type = sanitize_text_field($_POST['file_type']);
    $file_id = intval($_POST['file_id']);
    
    if (!flm_can_edit_lesson($lesson_id)) {
        wp_send_json_error(array('message' => 'Permission denied.'));
    }
    
    $allowed_types = array('student', 'teacher', 'audio');
    if (!in_array($file_type, $allowed_types)) {
        wp_send_json_error(array('message' => 'Invalid file type.'));
    }
    
    $meta_key = '_flm_' . $file_type . '_file';
    update_post_meta($lesson_id, $meta_key, $file_id);
    
    wp_send_json_success(array('message' => 'File updated successfully.'));
}

/* ==========================
   FILE DELETE HANDLER
   ========================== */

add_action('wp_ajax_flm_delete_file', 'flm_delete_file_ajax');
function flm_delete_file_ajax() {
    $lesson_id = intval($_POST['lesson_id']);
    $file_type = sanitize_text_field($_POST['file_type']);
    
    if (!flm_can_edit_lesson($lesson_id)) {
        wp_send_json_error(array('message' => 'Permission denied.'));
    }
    
    $allowed_types = array('student', 'teacher', 'audio');
    if (!in_array($file_type, $allowed_types)) {
        wp_send_json_error(array('message' => 'Invalid file type.'));
    }
    
    $meta_key = '_flm_' . $file_type . '_file';
    delete_post_meta($lesson_id, $meta_key);
    
    wp_send_json_success(array('message' => 'File deleted successfully.'));
}

/* ==========================
   LESSON DELETE HANDLER
   ========================== */

add_action('wp_ajax_flm_delete_lesson', 'flm_delete_lesson_ajax');
function flm_delete_lesson_ajax() {
    // Nonce is checked. If it fails, an appropriate error is sent.
    if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'flm_delete_lesson')) {
        wp_send_json_error(array('message' => 'Security check failed. Nonce mismatch.'));
    }
    
    $lesson_id = intval($_POST['lesson_id']);
    
    if (!$lesson_id || get_post_type($lesson_id) !== 'farsi_lesson') {
        wp_send_json_error(array('message' => 'Invalid lesson ID provided.'));
    }
    
    if (!flm_can_delete_lesson($lesson_id)) {
        wp_send_json_error(array('message' => 'Permission denied. You cannot delete this lesson.'));
    }
    
    $deleted = wp_delete_post($lesson_id, true);
    
    if ($deleted) {
        // FIX: Use stable path constant to load cache clearer without crashing
        require_once FLM_PLUGIN_PATH . 'includes/cache-auto-clear.php';
        
        if (function_exists('flm_clear_lesson_cache')) {
            flm_clear_lesson_cache();
        }

        wp_send_json_success(array('message' => 'Lesson deleted successfully.'));
    } else {
        // This usually means deletion failed due to database or other unknown error.
        wp_send_json_error(array('message' => 'Failed to delete lesson. Check WordPress debug log.'));
    }
}

/* ==========================
   AJAX HANDLER: SUBMISSION DELETE
   ========================== */

add_action('wp_ajax_flm_delete_submission', 'flm_delete_submission_ajax');
function flm_delete_submission_ajax() {
    if (!is_user_logged_in()) {
        wp_send_json_error(array('message' => 'Not logged in.'));
    }
    
    $submission_id = intval($_POST['submission_id']);
    
    if (!$submission_id || get_post_type($submission_id) !== 'farsi_submission') {
        wp_send_json_error(array('message' => 'Invalid submission ID.'));
    }

    $mentor_email = get_post_meta($submission_id, '_flm_mentor_email', true);
    $current_user_email = wp_get_current_user()->user_email;

    // Security check: Only the assigned mentor or an administrator/team leader can delete
    if ($mentor_email !== $current_user_email && !current_user_can('administrator') && !current_user_can('flm_team_leader')) {
         wp_send_json_error(array('message' => 'Permission denied.'));
    }
    
    $deleted = wp_delete_post($submission_id, true);
    
    if ($deleted) {
        // FIX: Use stable path constant to load cache clearer without crashing
        require_once FLM_PLUGIN_PATH . 'includes/cache-auto-clear.php';
        if (function_exists('flm_clear_lesson_cache')) {
            flm_clear_lesson_cache();
        }
        wp_send_json_success(array('message' => 'Submission deleted successfully.'));
    } else {
        wp_send_json_error(array('message' => 'Failed to delete submission.'));
    }
}