<?php
/**
 * Auto Cache Clear System
 * Automatically clears cache when lessons are created, updated, or deleted
 */

if (!defined('ABSPATH')) exit;

/* ==========================================================================
   AUTO-CLEAR CACHE WHEN LESSON IS CREATED/UPDATED/DELETED
   ========================================================================== */

add_action('save_post_farsi_lesson', 'flm_auto_clear_cache_on_lesson_save', 10, 3);
function flm_auto_clear_cache_on_lesson_save($post_id, $post, $update) {
    
    // Don't clear cache for autosaves or revisions
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) return;
    if (wp_is_post_revision($post_id)) return;
    if (wp_is_post_autosave($post_id)) return;
    
    // Only clear cache for published lessons
    if ($post->post_status !== 'publish') return;
    
    // Clear cache!
    flm_clear_lesson_cache();
}

// Also clear cache when lesson is deleted
add_action('delete_post', 'flm_auto_clear_cache_on_lesson_delete', 10, 1);
function flm_auto_clear_cache_on_lesson_delete($post_id) {
    if (get_post_type($post_id) === 'farsi_lesson') {
        flm_clear_lesson_cache();
    }
}

/* ==========================================================================
   CACHE CLEARING FUNCTION - Works with ALL major cache plugins!
   ========================================================================== */

function flm_clear_lesson_cache() {
    
    // Clear WordPress object cache
    wp_cache_flush();
    
    // Get URLs that need cache clearing
    $urls_to_clear = array(
        home_url('/material-list/'),
        home_url('/my-dashboard/'),
        home_url('/my-lessons/'),
        home_url('/lessons/'),
        home_url('/upload-materials/'),
    );
    
    // 1. WP Super Cache
    if (function_exists('wp_cache_clear_cache')) {
        wp_cache_clear_cache();
    }
    
    // 2. W3 Total Cache
    if (function_exists('w3tc_flush_all')) {
        w3tc_flush_all();
    }
    
    // 3. WP Rocket
    if (function_exists('rocket_clean_domain')) {
        rocket_clean_domain();
    }
    
    // 4. LiteSpeed Cache
    if (class_exists('LiteSpeed_Cache_API')) {
        LiteSpeed_Cache_API::purge_all();
    }
    
    // 5. Autoptimize
    if (class_exists('autoptimizeCache')) {
        autoptimizeCache::clearall();
    }
    
    // 6. WP Fastest Cache
    if (class_exists('WpFastestCache')) {
        $wpfc = new WpFastestCache();
        $wpfc->deleteCache();
    }
    
    // 7. Comet Cache
    if (class_exists('comet_cache')) {
        comet_cache::clear();
    }
    
    // 8. Cache Enabler
    if (class_exists('Cache_Enabler')) {
        Cache_Enabler::clear_total_cache();
    }
    
    // 9. WP-Optimize Cache
    if (class_exists('WP_Optimize') && method_exists('WP_Optimize', 'get_page_cache')) {
        $wp_optimize = WP_Optimize();
        $wp_optimize->get_page_cache()->purge();
    }
    
    // 10. Breeze Cache (Cloudways) - SPECIAL HANDLING!
    if (class_exists('Breeze_PurgeCache')) {
        // Clear ALL Breeze cache
        Breeze_PurgeCache::breeze_cache_flush();
        
        // Also clear Varnish cache (Cloudways server cache)
        do_action('breeze_clear_all_cache');
        
        // Clear specific URLs
        if (method_exists('Breeze_PurgeCache', 'breeze_purge_cache')) {
            foreach ($urls_to_clear as $url) {
                Breeze_PurgeCache::breeze_purge_cache($url);
            }
        }
        
        // Clear Varnish for entire domain (nuclear option for Cloudways)
        if (class_exists('Breeze_PurgeVarnish')) {
            $purge_varnish = new Breeze_PurgeVarnish();
            if (method_exists($purge_varnish, 'purge_cache')) {
                $purge_varnish->purge_cache();
            }
        }
    }
    
    // 11. Hummingbird Cache
    if (class_exists('Hummingbird\\WP_Hummingbird')) {
        do_action('wphb_clear_page_cache');
    }
    
    // 12. SG Optimizer (SiteGround)
    if (function_exists('sg_cachepress_purge_cache')) {
        sg_cachepress_purge_cache();
    }
    
    // 13. Swift Performance
    if (class_exists('Swift_Performance_Cache')) {
        Swift_Performance_Cache::clear_all_cache();
    }
    
    // 14. Cachify
    if (class_exists('Cachify')) {
        Cachify::flush_total_cache();
    }
    
    // 15. Simple Cache
    if (class_exists('Simple_Cache')) {
        Simple_Cache::clear_cache();
    }
    
    // CLOUDWAYS VARNISH - Alternative method via cURL (if above doesn't work)
    flm_purge_cloudways_varnish($urls_to_clear);
    
    // Log for debugging (optional - remove in production)
    if (defined('WP_DEBUG') && WP_DEBUG) {
        error_log('FLM: Auto-cleared cache (including Cloudways Varnish) after lesson save/delete');
    }
}

/**
 * Purge Cloudways Varnish Cache via HTTP PURGE method
 * This directly clears the server-level cache
 */
function flm_purge_cloudways_varnish($urls = array()) {
    
    // If no specific URLs, purge homepage
    if (empty($urls)) {
        $urls = array(home_url('/'));
    }
    
    foreach ($urls as $url) {
        // Parse URL
        $parsed = parse_url($url);
        $host = $parsed['host'];
        $path = isset($parsed['path']) ? $parsed['path'] : '/';
        
        // Send PURGE request to Varnish
        $response = wp_remote_request($url, array(
            'method' => 'PURGE',
            'headers' => array(
                'Host' => $host,
            ),
            'timeout' => 5,
            'sslverify' => false,
        ));
        
        // Also try BAN method (some Cloudways servers use this)
        wp_remote_request($url, array(
            'method' => 'BAN',
            'headers' => array(
                'Host' => $host,
            ),
            'timeout' => 5,
            'sslverify' => false,
        ));
    }
    
    // Also purge entire domain (nuclear option)
    $home_url = home_url('/');
    wp_remote_request($home_url . '.*', array(
        'method' => 'PURGE',
        'timeout' => 5,
        'sslverify' => false,
    ));
}

/* ==========================================================================
   PREVENT CACHING OF DYNAMIC PAGES (Backup Method)
   ========================================================================== */

add_action('template_redirect', 'flm_prevent_cache_on_dynamic_pages');
function flm_prevent_cache_on_dynamic_pages() {
    
    // List of pages that should NEVER be cached
    $dynamic_pages = array(
        'my-dashboard',
        'upload-materials',
        'my-lessons',
        'material-list',
        'user-profile-page',
        'my-submissions'
    );
    
    // Check if we're on one of these pages
    global $post;
    if ($post && in_array($post->post_name, $dynamic_pages)) {
        
        // Send no-cache headers
        if (!headers_sent()) {
            header('Cache-Control: no-cache, must-revalidate, max-age=0');
            header('Pragma: no-cache');
            header('Expires: Wed, 11 Jan 1984 05:00:00 GMT');
        }
        
        // Tell cache plugins not to cache this page
        if (!defined('DONOTCACHEPAGE')) {
            define('DONOTCACHEPAGE', true);
        }
        
        // WP Rocket specific
        if (!defined('DONOTROCKETOPTIMIZE')) {
            define('DONOTROCKETOPTIMIZE', true);
        }
        
        // LiteSpeed specific
        if (!defined('LSCACHE_NO_CACHE')) {
            define('LSCACHE_NO_CACHE', true);
        }
    }
}

/* ==========================================================================
   ADMIN NOTICE - Shows when cache is cleared
   ========================================================================== */

add_action('admin_notices', 'flm_cache_cleared_notice');
function flm_cache_cleared_notice() {
    
    // Only show on lesson edit pages
    $screen = get_current_screen();
    if (!$screen || $screen->post_type !== 'farsi_lesson') {
        return;
    }
    
    // Check if we just saved a lesson
    if (isset($_GET['message']) && $_GET['message'] == '1') {
        ?>
        <div class="notice notice-success is-dismissible">
            <p><strong>✅ Lesson saved!</strong> Cache automatically cleared - instructors will see it immediately.</p>
        </div>
        <?php
    }
}
