<?php
/**
 * Custom Dashboard
 * User dashboard with lessons, quick actions, and notifications
 */

if (!defined('ABSPATH')) exit;

// FIX: Ensure core constant is defined in case of early AJAX execution
if (!defined('DAY_IN_SECONDS')) {
    define('DAY_IN_SECONDS', 86400);
}

/* ==========================================================================
   DASHBOARD SHORTCODE
   ========================================================================== */

add_shortcode('farsi_dashboard', 'flm_dashboard_shortcode');
function flm_dashboard_shortcode() {
    
    // If not logged in, redirect with JavaScript (failsafe)
    if (!is_user_logged_in()) {
        ?>
        <script type="text/javascript">
            window.location.replace('<?php echo esc_js(home_url('/login/')); ?>');
        </script>
        <noscript>
            <meta http-equiv="refresh" content="0;url=<?php echo esc_url(home_url('/login/')); ?>">
        </noscript>
        <?php
        exit; // Stop all further execution
    }
    
    $current_user = wp_get_current_user();
    $user_id = get_current_user_id();
    
    ob_start();
    ?>
    
    <div class="flm-dashboard-wrapper">
        
        <div class="flm-dashboard-header">
            <h1 class="flm-dashboard-title">Welcome, <?php echo esc_html($current_user->display_name); ?>!</h1>
            <p class="flm-dashboard-subtitle">Manage your lessons and profile</p>
        </div>
        
        <div class="flm-dashboard-actions">
            <a href="<?php echo home_url('/upload-materials/'); ?>" class="flm-dashboard-btn flm-dashboard-btn-primary">
                <i class="fas fa-plus-circle"></i> Upload New Lesson
            </a>
            <a href="<?php echo home_url('/user-profile-page/'); ?>" class="flm-dashboard-btn flm-dashboard-btn-secondary">
                <i class="fas fa-user"></i> My Profile
            </a>
            <a href="<?php echo home_url('/my-submissions/'); ?>" class="flm-dashboard-btn flm-dashboard-btn-secondary flm-submissions-btn-anchor">
                <i class="fas fa-inbox"></i> View Submissions
                <span class="flm-submissions-count" style="display:none;"></span>
            </a>
        </div>
        
        <div id="flm-notifications-container">
            <div style="text-align:center;padding:40px;margin-bottom:30px;background:#f9f9f9;border:1px solid #e0e0e0;">
                <i class="fas fa-spinner fa-spin" style="font-size:24px;margin-right:10px;color:#999;"></i> Loading submissions...
            </div>
        </div>
        
        <div class="flm-dashboard-section">
            <h2 class="flm-section-title">
                <i class="fas fa-book"></i> My Lessons
            </h2>
            <?php echo do_shortcode('[farsi_my_lessons]'); ?>
        </div>
        
    </div>
    
    <?php
    return ob_get_clean();
}

/* ==========================================================================
   PROFILE SHORTCODE
   ========================================================================== */

add_shortcode('farsi_profile', 'flm_profile_shortcode');
function flm_profile_shortcode() {
    
    // If not logged in, redirect with JavaScript (failsafe)
    if (!is_user_logged_in()) {
        ?>
        <script type="text/javascript">
            window.location.replace('<?php echo esc_js(home_url('/login/')); ?>');
        </script>
        <noscript>
            <meta http-equiv="refresh" content="0;url=<?php echo esc_url(home_url('/login/')); ?>">
        </noscript>
        <?php
        exit; // Stop all further execution
    }
    
    $current_user = wp_get_current_user();
    
    ob_start();
    ?>
    
    <div class="flm-dashboard-wrapper">
        
        <div class="flm-dashboard-header">
            <h1 class="flm-dashboard-title">My Profile</h1>
            <p class="flm-dashboard-subtitle">Manage your account settings</p>
        </div>
        
        <div class="flm-dashboard-section">
            <div class="flm-profile-container">
                
                <div class="flm-profile-info">
                    <div class="flm-profile-row">
                        <span class="flm-profile-label">Display Name:</span>
                        <span class="flm-profile-value"><?php echo esc_html($current_user->display_name); ?></span>
                    </div>
                    <div class="flm-profile-row">
                        <span class="flm-profile-label">Email Address:</span>
                        <span class="flm-profile-value"><?php echo esc_html($current_user->user_email); ?></span>
                    </div>
                    <div class="flm-profile-row">
                        <span class="flm-profile-label">Username:</span>
                        <span class="flm-profile-value"><?php echo esc_html($current_user->user_login); ?></span>
                    </div>
                    <div class="flm-profile-row">
                        <span class="flm-profile-label">Role:</span>
                        <span class="flm-profile-value"><?php echo esc_html(ucfirst(str_replace('flm_', '', $current_user->roles[0]))); ?></span>
                    </div>
                </div>
                
                <div class="flm-profile-actions">
                    <button class="flm-dashboard-btn flm-dashboard-btn-primary" id="flm-edit-profile-btn">
                        <i class="fas fa-edit"></i> Edit Profile
                    </button>
                    <a href="<?php echo home_url('/my-dashboard/'); ?>" class="flm-dashboard-btn flm-dashboard-btn-secondary">
                        <i class="fas fa-arrow-left"></i> Back to Dashboard
                    </a>
                    <a href="<?php echo wp_logout_url(home_url('/login/')); ?>" class="flm-dashboard-btn flm-dashboard-btn-logout">
                        <i class="fas fa-sign-out-alt"></i> Log Out
                    </a>
                </div>
                
                <div class="flm-profile-edit-form" id="flm-profile-edit-form" style="display:none;">
                    <form id="flm-update-profile-form">
                        <?php wp_nonce_field('flm_update_profile', 'flm_profile_nonce'); ?>
                        
                        <div class="flm-form-row">
                            <label>Display Name *</label>
                            <input type="text" name="display_name" value="<?php echo esc_attr($current_user->display_name); ?>" required>
                        </div>
                        
                        <div class="flm-form-row">
                            <label>Email Address *</label>
                            <input type="email" name="user_email" value="<?php echo esc_attr($current_user->user_email); ?>" required>
                        </div>
                        
                        <div class="flm-form-row">
                            <label>New Password (leave blank to keep current)</label>
                            <input type="password" name="new_password" placeholder="Enter new password" autocomplete="new-password">
                            <p class="flm-note">Minimum 6 characters</p>
                        </div>
                        
                        <div class="flm-form-row">
                            <label>Confirm New Password</label>
                            <input type="password" name="confirm_password" placeholder="Confirm new password" autocomplete="new-password">
                        </div>
                        
                        <div class="flm-profile-form-buttons">
                            <button type="submit" class="flm-dashboard-btn flm-dashboard-btn-primary">
                                <i class="fas fa-save"></i> Save Changes
                            </button>
                            <button type="button" class="flm-dashboard-btn flm-dashboard-btn-secondary" id="flm-cancel-profile-edit">
                                Cancel
                            </button>
                        </div>
                        
                        <div id="flm-profile-message" class="flm-message" style="display:none;"></div>
                    </form>
                </div>
                
            </div>
        </div>
        
    </div>
    
    <?php
    return ob_get_clean();
}

/* ==========================================================================
   GET USER NOTIFICATIONS - ACTUAL STUDENT SUBMISSIONS (Used by AJAX)
   ========================================================================== */

function flm_get_user_notifications($user_id) {
    $user = get_user_by('id', $user_id);
    if (!$user) {
        return array();
    }
    
    $user_email = $user->user_email;
    $notifications = array();
    
    // Get all submissions where this user is the mentor
    $submissions = get_posts(array(
        'post_type' => 'farsi_submission',
        'posts_per_page' => 20,
        'meta_query' => array(
            array(
                'key' => '_flm_mentor_email',
                'value' => $user_email,
                'compare' => '='
            )
        ),
        'orderby' => 'date',
        'order' => 'DESC'
    ));
    
    foreach ($submissions as $submission) {
        $student_email = get_post_meta($submission->ID, '_flm_student_email', true);
        $subject = get_post_meta($submission->ID, '_flm_subject', true);
        $submission_date = get_post_meta($submission->ID, '_flm_submission_date', true);
        $files = json_decode(get_post_meta($submission->ID, '_flm_files', true), true);
        
        // Check if notification has been read
        $is_read = get_post_meta($submission->ID, '_flm_notification_read_' . $user_id, true);
        
        if (!$is_read) {
            $notifications[] = array(
                'id' => $submission->ID,
                'student_email' => $student_email,
                'subject' => $subject,
                'date' => human_time_diff(strtotime($submission_date), current_time('timestamp')) . ' ago',
                'file_count' => is_array($files) ? count($files) : 0
            );
        }
    }
    
    return $notifications;
}

// Helper function to count unread submissions
function flm_get_submissions_count_for_mentor($mentor_email) {
    $user = get_user_by('email', $mentor_email);
    if (!$user) {
        return 0;
    }
    
    $submissions = get_posts(array(
        'post_type' => 'farsi_submission',
        'posts_per_page' => -1,
        'meta_query' => array(
            array(
                'key' => '_flm_mentor_email',
                'value' => $mentor_email,
                'compare' => '='
            )
        ),
        'fields' => 'ids'
    ));
    
    $unread_count = 0;
    foreach ($submissions as $submission_id) {
        $is_read = get_post_meta($submission_id, '_flm_notification_read_' . $user->ID, true);
        if (!$is_read) {
            $unread_count++;
        }
    }
    
    return $unread_count;
}

/* ==========================================================================
   MARK NOTIFICATION AS READ AJAX
   ========================================================================== */

add_action('wp_ajax_flm_mark_notification_read', 'flm_mark_notification_read');
function flm_mark_notification_read() {
    
    if (!is_user_logged_in()) {
        wp_send_json_error(array('message' => 'Not logged in.'));
    }
    
    $notification_id = intval($_POST['notification_id']);
    $user_id = get_current_user_id();
    
    if (!$notification_id) {
        wp_send_json_error(array('message' => 'Invalid notification.'));
    }
    
    // Mark as read
    update_post_meta($notification_id, '_flm_notification_read_' . $user_id, '1');
    
    wp_send_json_success(array('message' => 'Marked as read.'));
}

/* ==========================================================================
   MY SUBMISSIONS SHORTCODE - For instructors to view submissions sent to them
   ========================================================================== */

add_shortcode('farsi_my_submissions', 'flm_my_submissions_shortcode');
function flm_my_submissions_shortcode() {
    
    // If not logged in, redirect with JavaScript (failsafe)
    if (!is_user_logged_in()) {
        ?>
        <script type="text/javascript">
            window.location.replace('<?php echo esc_js(home_url('/login/')); ?>');
        </script>
        <noscript>
            <meta http-equiv="refresh" content="0;url=<?php echo esc_url(home_url('/login/')); ?>">
        </noscript>
        <?php
        exit;
    }
    
    $current_user = wp_get_current_user();
    $user_email = $current_user->user_email;
    
    // Get all submissions for this mentor
    $submissions = get_posts(array(
        'post_type' => 'farsi_submission',
        'posts_per_page' => -1,
        'meta_query' => array(
            array(
                'key' => '_flm_mentor_email',
                'value' => $user_email,
                'compare' => '='
            )
        ),
        'orderby' => 'date',
        'order' => 'DESC'
    ));
    
    // Check if viewing specific submission
    $viewing_id = isset($_GET['view']) ? intval($_GET['view']) : 0;
    $viewing_submission = null;
    
    if ($viewing_id) {
        $viewing_submission = get_post($viewing_id);
        if ($viewing_submission && get_post_meta($viewing_id, '_flm_mentor_email', true) === $user_email) {
            // Mark as read when viewing
            update_post_meta($viewing_id, '_flm_notification_read_' . get_current_user_id(), '1');
        } else {
            $viewing_submission = null; // Not authorized
        }
    }
    
    ob_start();
    ?>
    
    <div class="flm-dashboard-wrapper">
        
        <?php if ($viewing_submission) : 
            // Viewing specific submission
            $student_email = get_post_meta($viewing_id, '_flm_student_email', true);
            $subject = get_post_meta($viewing_id, '_flm_subject', true);
            $notes = get_post_meta($viewing_id, '_flm_notes', true);
            $files = json_decode(get_post_meta($viewing_id, '_flm_files', true), true);
            $submission_date = get_post_meta($viewing_id, '_flm_submission_date', true);
        ?>
        
            <div class="flm-dashboard-header">
                <a href="<?php echo home_url('/my-submissions/'); ?>" style="color: #666; text-decoration: none; font-size: 14px; display: inline-block; margin-bottom: 10px;">
                    <i class="fas fa-arrow-left"></i> Back to All Submissions
                </a>
                <h1 class="flm-dashboard-title">Submission Details</h1>
            </div>
            
            <div class="flm-dashboard-section" style="background: #f9f9f9; padding: 25px;">
                
                <div style="margin-bottom: 20px;">
                    <strong style="font-size: 13px; text-transform: uppercase; color: #666; letter-spacing: 0.5px;">Student:</strong><br>
                    <span style="font-size: 16px; color: #000;"><?php echo esc_html($student_email); ?></span>
                </div>
                
                <div style="margin-bottom: 20px;">
                    <strong style="font-size: 13px; text-transform: uppercase; color: #666; letter-spacing: 0.5px;">Subject:</strong><br>
                    <span style="font-size: 16px; color: #000;"><?php echo esc_html($subject); ?></span>
                </div>
                
                <div style="margin-bottom: 20px;">
                    <strong style="font-size: 13px; text-transform: uppercase; color: #666; letter-spacing: 0.5px;">Submitted:</strong><br>
                    <span style="font-size: 16px; color: #000;"><?php echo esc_html($submission_date); ?></span>
                </div>
                
                <?php if ($notes) : ?>
                <div style="margin-bottom: 20px;">
                    <strong style="font-size: 13px; text-transform: uppercase; color: #666; letter-spacing: 0.5px;">Student Notes:</strong><br>
                    <div style="background: #fff; padding: 15px; margin-top: 10px; border-left: 3px solid #2271b1;">
                        <?php echo nl2br(esc_html($notes)); ?>
                    </div>
                </div>
                <?php endif; ?>
                
                <?php if ($files && is_array($files)) : ?>
                <div style="margin-bottom: 20px;">
                    <strong style="font-size: 13px; text-transform: uppercase; color: #666; letter-spacing: 0.5px; display: block; margin-bottom: 15px;">Submitted Files:</strong>
                    <?php foreach ($files as $file) : ?>
                        <div style="background: #fff; padding: 15px; margin-bottom: 10px; display: flex; align-items: center; justify-content: space-between; border: 1px solid #e0e0e0;">
                            <div>
                                <i class="fas fa-file" style="margin-right: 10px; color: #666;"></i>
                                <strong><?php echo esc_html($file['name']); ?></strong>
                            </div>
                            <a href="<?php echo esc_url($file['path']); ?>" class="flm-dashboard-btn flm-dashboard-btn-primary" target="_blank" download>
                                <i class="fas fa-download"></i> Download
                            </a>
                        </div>
                    <?php endforeach; ?>
                </div>
                <?php endif; ?>
                
            </div>
        
        <?php else : 
            // List all submissions
        ?>
        
            <div class="flm-dashboard-header">
                <h1 class="flm-dashboard-title">Student Submissions</h1>
                <p class="flm-dashboard-subtitle">View all homework submissions sent to you</p>
            </div>
            
            <?php if (empty($submissions)) : ?>
                
                <div style="text-align: center; padding: 60px 20px; color: #999;">
                    <i class="fas fa-inbox" style="font-size: 64px; margin-bottom: 20px; opacity: 0.3;"></i>
                    <p style="font-size: 16px;">No submissions yet.</p>
                </div>
                
            <?php else : ?>
                
                <div class="flm-dashboard-section">
                    <table class="flm-list">
                        <thead>
                            <tr>
                                <th style="width: 25%;">Student</th>
                                <th style="width: 35%;">Subject</th>
                                <th style="width: 15%;">Date</th>
                                <th style="width: 10%;">Files</th>
                                <th style="width: 15%;">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($submissions as $submission) : 
                                $student_email = get_post_meta($submission->ID, '_flm_student_email', true);
                                $subject = get_post_meta($submission->ID, '_flm_subject', true);
                                $submission_date = get_post_meta($submission->ID, '_flm_submission_date', true);
                                $files = json_decode(get_post_meta($submission->ID, '_flm_files', true), true);
                                $file_count = is_array($files) ? count($files) : 0;
                                $is_read = get_post_meta($submission->ID, '_flm_notification_read_' . get_current_user_id(), true);
                            ?>
                                <tr id="submission-row-<?php echo $submission->ID; ?>" style="<?php echo !$is_read ? 'background: #fff3cd !important;' : ''; ?>">
                                    <td>
                                        <?php echo esc_html($student_email); ?>
                                        <?php if (!$is_read) : ?>
                                            <span style="color: #dc3545; font-weight: 600; margin-left: 5px;">NEW</span>
                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo esc_html($subject); ?></td>
                                    <td><?php echo esc_html(date('M j, Y', strtotime($submission_date))); ?></td>
                                    <td><?php echo $file_count; ?> file<?php echo $file_count != 1 ? 's' : ''; ?></td>
                                    <td>
                                        <a href="<?php echo home_url('/my-submissions/?view=' . $submission->ID); ?>" class="flm-btn flm-btn-view" title="View Details">
                                            <i class="fas fa-eye"></i>
                                        </a>
                                        <button class="flm-btn flm-btn-delete flm-delete-submission-btn" data-submission-id="<?php echo $submission->ID; ?>" title="Delete Submission">
                                            <i class="fas fa-trash"></i>
                                        </button>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
                
            <?php endif; ?>
        
        <?php endif; ?>
        
    </div>
    
    <?php
    return ob_get_clean();
}

/* ==========================================================================
   CRON JOB: DELETE OLD SUBMISSIONS (Runs daily, deletes posts older than 7 days)
   ========================================================================== */

function flm_delete_old_submissions() {
    // Cutoff date is 7 days ago
    $cutoff_time = current_time('timestamp') - (7 * DAY_IN_SECONDS);
    $cutoff_date = date('Y-m-d H:i:s', $cutoff_time);

    // Query for submissions older than the cutoff date
    $old_submissions = get_posts(array(
        'post_type' => 'farsi_submission',
        'posts_per_page' => -1,
        'date_query' => array(
            'before' => $cutoff_date,
            'inclusive' => true,
        ),
        'fields' => 'ids',
        'post_status' => 'publish'
    ));

    if (empty($old_submissions)) {
        return;
    }

    foreach ($old_submissions as $submission_id) {
        // Safely delete the post, forcing it to skip trash
        wp_delete_post($submission_id, true);
    }
}


/* ==========================================================================
   UPDATE PROFILE AJAX
   ========================================================================== */

add_action('wp_ajax_flm_update_profile', 'flm_update_profile');
function flm_update_profile() {
    
    if (!isset($_POST['flm_profile_nonce']) || !wp_verify_nonce($_POST['flm_profile_nonce'], 'flm_update_profile')) {
        wp_send_json_error(array('message' => 'Security check failed.'));
    }
    
    $user_id = get_current_user_id();
    
    if (!$user_id) {
        wp_send_json_error(array('message' => 'Not logged in.'));
    }
    
    $display_name = sanitize_text_field($_POST['display_name']);
    $user_email = sanitize_email($_POST['user_email']);
    $new_password = $_POST['new_password'];
    $confirm_password = $_POST['confirm_password'];
    
    // Validate email
    if (!is_email($user_email)) {
        wp_send_json_error(array('message' => 'Invalid email address.'));
    }
    
    // Check if email is already used by another user
    $email_exists = email_exists($user_email);
    if ($email_exists && $email_exists != $user_id) {
        wp_send_json_error(array('message' => 'Email address is already in use.'));
    }
    
    // Update user data
    $user_data = array(
        'ID' => $user_id,
        'display_name' => $display_name,
        'user_email' => $user_email
    );
    
    // Handle password change
    if (!empty($new_password)) {
        if ($new_password !== $confirm_password) {
            wp_send_json_error(array('message' => 'Passwords do not match.'));
        }
        
        if (strlen($new_password) < 6) {
            wp_send_json_error(array('message' => 'Password must be at least 6 characters.'));
        }
        
        $user_data['user_pass'] = $new_password;
    }
    
    $updated = wp_update_user($user_data);
    
    if (is_wp_error($updated)) {
        wp_send_json_error(array('message' => 'Failed to update profile.'));
    }
    
    wp_send_json_success(array('message' => 'Profile updated successfully!'));
}