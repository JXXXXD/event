<?php
/**
 * Admin Pages - With Token Management
 */

if (!defined('ABSPATH')) exit;

add_action('admin_menu', 'flm_register_admin_menu');
function flm_register_admin_menu() {
    add_menu_page('Farsi Learning', 'Farsi Learning', 'read', 'farsi-learning-manager', 'flm_render_dashboard', 'dashicons-welcome-learn-more', 30);
    add_submenu_page('farsi-learning-manager', 'Dashboard', 'Dashboard', 'read', 'farsi-learning-manager', 'flm_render_dashboard');
    add_submenu_page('farsi-learning-manager', 'Submission Log', 'Submission Log', 'read', 'flm-submission-log', 'flm_render_submission_log');
    add_submenu_page('farsi-learning-manager', 'Security Codes', 'Security Codes', 'manage_options', 'flm-security-codes', 'flm_render_security_codes_page');
    add_submenu_page('farsi-learning-manager', 'Settings', 'Settings', 'manage_options', 'flm-settings', 'flm_render_settings_page');
}

function flm_render_dashboard() {
    $total_lessons = wp_count_posts('farsi_lesson')->publish;
    $total_submissions = wp_count_posts('farsi_submission')->publish;
    $current_user = wp_get_current_user();
    $user_lessons = 0;
    if (in_array('flm_instructor', $current_user->roles)) {
        $user_lessons = count(get_posts(array('post_type' => 'farsi_lesson', 'author' => $current_user->ID, 'posts_per_page' => -1, 'fields' => 'ids')));
    }
    ?>
    <div class="wrap flm-dashboard">
        <h1>Farsi Learning Manager</h1>
        <div class="flm-stats-grid">
            <div class="flm-stat-card">
                <span class="flm-stat-number"><?php echo esc_html($total_lessons); ?></span>
                <span class="flm-stat-label">Total Lessons</span>
                <a href="<?php echo admin_url('edit.php?post_type=farsi_lesson'); ?>" class="flm-stat-link">View All</a>
            </div>
            <?php if ($user_lessons > 0) : ?>
            <div class="flm-stat-card">
                <span class="flm-stat-number"><?php echo esc_html($user_lessons); ?></span>
                <span class="flm-stat-label">Your Lessons</span>
                <a href="<?php echo admin_url('edit.php?post_type=farsi_lesson&author=' . $current_user->ID); ?>" class="flm-stat-link">View Yours</a>
            </div>
            <?php endif; ?>
            <div class="flm-stat-card">
                <span class="flm-stat-number"><?php echo esc_html($total_submissions); ?></span>
                <span class="flm-stat-label">Total Submissions</span>
                <a href="<?php echo admin_url('admin.php?page=flm-submission-log'); ?>" class="flm-stat-link">View Log</a>
            </div>
            <div class="flm-stat-card flm-stat-action">
                <a href="<?php echo admin_url('post-new.php?post_type=farsi_lesson'); ?>" class="button button-primary button-hero">Create New Lesson</a>
            </div>
        </div>
        <div class="flm-quick-links">
            <h2>Quick Links</h2>
            <ul>
                <li><a href="<?php echo admin_url('edit.php?post_type=farsi_lesson'); ?>">All Lessons</a></li>
                <li><a href="<?php echo admin_url('admin.php?page=flm-submission-log'); ?>">Submission Log</a></li>
                <li><a href="<?php echo admin_url('admin.php?page=flm-security-codes'); ?>">Security Codes</a></li>
                <li><a href="<?php echo admin_url('admin.php?page=flm-settings'); ?>">Settings & Shortcodes</a></li>
            </ul>
        </div>
    </div>
    <?php
}

function flm_render_submission_log() {
    $submissions = get_posts(array('post_type' => 'farsi_submission', 'posts_per_page' => 100, 'orderby' => 'date', 'order' => 'DESC'));
    ?>
    <div class="wrap flm-submission-log">
        <h1>Submission Log</h1>
        <?php if ($submissions) : ?>
            <table class="wp-list-table widefat fixed striped">
                <thead><tr><th>Student Email</th><th>Mentor Email</th><th>Subject</th><th>Date & Time</th><th>Notes</th><th>Files</th></tr></thead>
                <tbody>
                    <?php foreach ($submissions as $sub) : 
                        $subject = get_post_meta($sub->ID, '_flm_subject', true);
                        $student_notes = get_post_meta($sub->ID, '_flm_notes', true);
                        $files = json_decode(get_post_meta($sub->ID, '_flm_files', true), true);
                    ?>
                        <tr>
                            <td><?php echo esc_html(get_post_meta($sub->ID, '_flm_student_email', true)); ?></td>
                            <td><?php echo esc_html(get_post_meta($sub->ID, '_flm_mentor_email', true)); ?></td>
                            <td><?php echo $subject ? esc_html($subject) : 'N/A'; ?></td>
                            <td><?php echo esc_html(get_post_meta($sub->ID, '_flm_submission_date', true)); ?></td>
                            <td><?php echo $student_notes ? esc_html(wp_trim_words($student_notes, 10)) : '-'; ?></td>
                            <td>
                                <?php if ($files && is_array($files)) : ?>
                                    <?php foreach ($files as $file) : ?>
                                        <a href="<?php echo esc_url($file['path']); ?>" target="_blank" class="button button-small" style="margin: 2px;"><?php echo esc_html($file['name']); ?></a><br>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php else : ?>
            <p>No submissions yet.</p>
        <?php endif; ?>
    </div>
    <?php
}

/* SECURITY CODES PAGE */
function flm_render_security_codes_page() {
    if (isset($_POST['flm_add_code']) && check_admin_referer('flm_security_codes_nonce', 'flm_security_codes_nonce')) {
        $code = sanitize_text_field($_POST['security_code']);
        $description = sanitize_text_field($_POST['code_description']);
        if (!empty($code)) {
            $codes = get_option('flm_security_codes', array());
            $codes[] = array('code' => $code, 'description' => $description, 'created' => current_time('mysql'), 'created_by' => get_current_user_id());
            update_option('flm_security_codes', $codes);
            echo '<div class="notice notice-success is-dismissible"><p>Security code added successfully!</p></div>';
        }
    }
    if (isset($_POST['flm_delete_code']) && check_admin_referer('flm_delete_code_nonce_' . $_POST['code_index'], 'flm_delete_code_nonce')) {
        $index = intval($_POST['code_index']);
        $codes = get_option('flm_security_codes', array());
        if (isset($codes[$index])) {
            unset($codes[$index]);
            $codes = array_values($codes);
            update_option('flm_security_codes', $codes);
            echo '<div class="notice notice-success is-dismissible"><p>Security code deleted successfully!</p></div>';
        }
    }
    $codes = get_option('flm_security_codes', array());
    ?>
    <div class="wrap">
        <h1>Security Codes Management</h1>
        <p>Create security codes that students must enter to submit their work. This prevents unauthorized submissions.</p>
        <div class="flm-settings-section" style="background: #fff; padding: 20px; border: 1px solid #ccc; margin: 20px 0;">
            <h2 style="margin-top: 0;">Create New Security Code</h2>
            <form method="post" action="">
                <?php wp_nonce_field('flm_security_codes_nonce', 'flm_security_codes_nonce'); ?>
                <table class="form-table">
                    <tr><th scope="row"><label for="security_code">Security Code *</label></th>
                    <td><input type="text" name="security_code" id="security_code" class="regular-text" required><p class="description">The code students will enter (e.g., FARSI2025, TEAM1, etc.)</p></td></tr>
                    <tr><th scope="row"><label for="code_description">Description</label></th>
                    <td><input type="text" name="code_description" id="code_description" class="large-text" placeholder="e.g., For Team Leader A, Spring 2025 students, etc."><p class="description">Optional: Note who this code is for</p></td></tr>
                </table>
                <p class="submit"><button type="submit" name="flm_add_code" class="button button-primary">Add Security Code</button></p>
            </form>
        </div>
        <div class="flm-settings-section" style="background: #fff; padding: 20px; border: 1px solid #ccc;">
            <h2 style="margin-top: 0;">Active Security Codes</h2>
            <?php if (empty($codes)) : ?>
                <p>No security codes created yet. Add one above to get started.</p>
            <?php else : ?>
                <table class="wp-list-table widefat fixed striped">
                    <thead><tr><th style="width: 20%;">Code</th><th style="width: 30%;">Description</th><th style="width: 20%;">Created</th><th style="width: 20%;">Created By</th><th style="width: 10%;">Actions</th></tr></thead>
                    <tbody>
                        <?php foreach ($codes as $index => $code_data) : 
                            $user = get_user_by('id', $code_data['created_by']);
                        ?>
                            <tr>
                                <td><strong><?php echo esc_html($code_data['code']); ?></strong></td>
                                <td><?php echo esc_html($code_data['description']); ?></td>
                                <td><?php echo esc_html($code_data['created']); ?></td>
                                <td><?php echo $user ? esc_html($user->display_name) : 'Unknown'; ?></td>
                                <td><form method="post" action="" style="display:inline;">
                                    <?php wp_nonce_field('flm_delete_code_nonce_' . $index, 'flm_delete_code_nonce'); ?>
                                    <input type="hidden" name="code_index" value="<?php echo $index; ?>">
                                    <button type="submit" name="flm_delete_code" class="button button-small" onclick="return confirm('Are you sure you want to delete this security code?');">Delete</button>
                                </form></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php endif; ?>
        </div>
    </div>
    <?php
}

function flm_render_settings_page() {
    ?>
    <div class="wrap flm-settings">
        <h1>Farsi Learning Manager - Settings & Shortcodes</h1>
        
        <!-- Quick Page Setup Guide -->
        <div class="flm-settings-section" style="background: #e7f5ff; padding: 20px; border: 1px solid #0066cc; margin-bottom: 20px;">
            <h2 style="margin-top: 0; color: #0066cc;">📋 Quick Page Setup Guide</h2>
            <p style="font-size: 14px; margin-bottom: 15px;">Create these pages with the corresponding shortcodes to get your site running:</p>
            <table class="wp-list-table widefat fixed striped" style="background: #fff;">
                <thead>
                    <tr>
                        <th style="width: 20%;">Page Title</th>
                        <th style="width: 20%;">URL Slug</th>
                        <th style="width: 30%;">Shortcode</th>
                        <th style="width: 30%;">Purpose</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td><strong>Login</strong></td>
                        <td><code>/login/</code></td>
                        <td><code>[farsi_login]</code></td>
                        <td>Custom login page (replaces wp-login.php)</td>
                    </tr>
                    <tr>
                        <td><strong>My Dashboard</strong></td>
                        <td><code>/my-dashboard/</code></td>
                        <td><code>[farsi_dashboard]</code></td>
                        <td>User dashboard with notifications & quick links</td>
                    </tr>
                    <tr>
                        <td><strong>My Profile</strong></td>
                        <td><code>/user-profile-page/</code></td>
                        <td><code>[farsi_profile]</code></td>
                        <td>User profile page with edit capability</td>
                    </tr>
                    <tr>
                        <td><strong>Upload Materials</strong></td>
                        <td><code>/upload-materials/</code></td>
                        <td><code>[farsi_instructor_form]</code></td>
                        <td>Instructors upload new lessons from frontend</td>
                    </tr>
                    <tr>
                        <td><strong>My Lessons</strong></td>
                        <td><code>/my-lessons/</code></td>
                        <td><code>[farsi_my_lessons]</code></td>
                        <td>Shows only current instructor's lessons</td>
                    </tr>
                    <tr>
                        <td><strong>All Lessons</strong></td>
                        <td><code>/lessons/</code></td>
                        <td><code>[farsi_lesson_list]</code></td>
                        <td>Shows all lessons from all instructors</td>
                    </tr>
                    <tr>
                        <td><strong>Submit Work</strong></td>
                        <td><code>/submit-work/</code></td>
                        <td><code>[farsi_student_form]</code></td>
                        <td>Students submit assignments to mentors</td>
                    </tr>
                </tbody>
            </table>
        </div>
        
        <!-- Login & Authentication -->
        <div class="flm-settings-section" style="background: #fff; padding: 20px; border: 1px solid #ccc; margin-bottom: 20px;">
            <h2 style="margin-top: 0;">🔐 Login & Authentication</h2>
            
            <div class="flm-shortcode-box" style="background: #f9f9f9; padding: 15px; margin-bottom: 20px; border-left: 4px solid #000;">
                <h3 style="margin-top: 0;">[farsi_login]</h3>
                <input type="text" value='[farsi_login]' readonly style="width: 100%; padding: 10px; font-family: monospace; font-size: 14px; background: #fff; border: 1px solid #000; margin-bottom: 10px;" onclick="this.select();">
                <p style="margin: 10px 0 5px 0;"><strong>Purpose:</strong> Custom login page with your logo</p>
                <p style="margin: 5px 0;"><strong>Features:</strong></p>
                <ul style="margin-top: 5px; margin-left: 20px;">
                    <li>Email + password authentication</li>
                    <li>Remember me option</li>
                    <li>Forgot password link</li>
                    <li>Redirects: Admins → wp-admin, Others → /my-dashboard/</li>
                </ul>
                <p style="margin: 5px 0;"><strong>Required Page:</strong> Create page at <code>/login/</code></p>
            </div>
        </div>
        
        <!-- Dashboard & Profile -->
        <div class="flm-settings-section" style="background: #fff; padding: 20px; border: 1px solid #ccc; margin-bottom: 20px;">
            <h2 style="margin-top: 0;">📊 Dashboard & Profile</h2>
            
            <div class="flm-shortcode-box" style="background: #f9f9f9; padding: 15px; margin-bottom: 20px; border-left: 4px solid #2271b1;">
                <h3 style="margin-top: 0;">[farsi_dashboard]</h3>
                <input type="text" value='[farsi_dashboard]' readonly style="width: 100%; padding: 10px; font-family: monospace; font-size: 14px; background: #fff; border: 1px solid #000; margin-bottom: 10px;" onclick="this.select();">
                <p style="margin: 10px 0 5px 0;"><strong>Purpose:</strong> Complete user dashboard</p>
                <p style="margin: 5px 0;"><strong>Features:</strong></p>
                <ul style="margin-top: 5px; margin-left: 20px;">
                    <li>Welcome message with user's name</li>
                    <li>Quick action buttons (Upload, Profile, Submit)</li>
                    <li>Notifications for new student submissions</li>
                    <li>My Lessons list with search</li>
                </ul>
                <p style="margin: 5px 0;"><strong>Required Page:</strong> Create page at <code>/my-dashboard/</code></p>
                <p style="margin: 5px 0;"><strong>Access:</strong> Logged-in users only</p>
            </div>
            
            <div class="flm-shortcode-box" style="background: #f9f9f9; padding: 15px; border-left: 4px solid #2271b1;">
                <h3 style="margin-top: 0;">[farsi_profile]</h3>
                <input type="text" value='[farsi_profile]' readonly style="width: 100%; padding: 10px; font-family: monospace; font-size: 14px; background: #fff; border: 1px solid #000; margin-bottom: 10px;" onclick="this.select();">
                <p style="margin: 10px 0 5px 0;"><strong>Purpose:</strong> User profile management page</p>
                <p style="margin: 5px 0;"><strong>Features:</strong></p>
                <ul style="margin-top: 5px; margin-left: 20px;">
                    <li>Display user information</li>
                    <li>Edit name and email</li>
                    <li>Change password</li>
                    <li>Back to dashboard button</li>
                </ul>
                <p style="margin: 5px 0;"><strong>Required Page:</strong> Create page at <code>/user-profile-page/</code></p>
                <p style="margin: 5px 0;"><strong>Access:</strong> Logged-in users only</p>
            </div>
        </div>
        
        <!-- Instructor Features -->
        <div class="flm-settings-section" style="background: #fff; padding: 20px; border: 1px solid #ccc; margin-bottom: 20px;">
            <h2 style="margin-top: 0;">👨‍🏫 Instructor Features</h2>
            
            <div class="flm-shortcode-box" style="background: #f9f9f9; padding: 15px; margin-bottom: 20px; border-left: 4px solid #10b981;">
                <h3 style="margin-top: 0;">[farsi_instructor_form]</h3>
                <input type="text" value='[farsi_instructor_form]' readonly style="width: 100%; padding: 10px; font-family: monospace; font-size: 14px; background: #fff; border: 1px solid #000; margin-bottom: 10px;" onclick="this.select();">
                <p style="margin: 10px 0 5px 0;"><strong>Purpose:</strong> Frontend form for instructors to upload new lessons</p>
                <p style="margin: 5px 0;"><strong>Features:</strong></p>
                <ul style="margin-top: 5px; margin-left: 20px;">
                    <li>Title and notes fields</li>
                    <li>Upload student file (PDF/Word)</li>
                    <li>Upload teacher file / answer key</li>
                    <li>Upload audio file (optional)</li>
                    <li>Media library integration</li>
                </ul>
                <p style="margin: 5px 0;"><strong>Required Page:</strong> Create page at <code>/upload-materials/</code></p>
                <p style="margin: 5px 0;"><strong>Access:</strong> Instructors and above only</p>
            </div>
            
            <div class="flm-shortcode-box" style="background: #f9f9f9; padding: 15px; border-left: 4px solid #10b981;">
                <h3 style="margin-top: 0;">[farsi_my_lessons]</h3>
                <input type="text" value='[farsi_my_lessons]' readonly style="width: 100%; padding: 10px; font-family: monospace; font-size: 14px; background: #fff; border: 1px solid #000; margin-bottom: 10px;" onclick="this.select();">
                <p style="margin: 10px 0 5px 0;"><strong>Purpose:</strong> Shows only current instructor's own lessons</p>
                <p style="margin: 5px 0;"><strong>Features:</strong></p>
                <ul style="margin-top: 5px; margin-left: 20px;">
                    <li>Real-time search by title, instructor, notes</li>
                    <li>Edit notes inline</li>
                    <li>Edit/delete own lessons</li>
                    <li>View lesson button</li>
                </ul>
                <p style="margin: 5px 0;"><strong>Required Page:</strong> Create page at <code>/my-lessons/</code> (or use in dashboard)</p>
                <p style="margin: 5px 0;"><strong>Access:</strong> Logged-in instructors only</p>
            </div>
        </div>
        
        <!-- Public Features -->
        <div class="flm-settings-section" style="background: #fff; padding: 20px; border: 1px solid #ccc; margin-bottom: 20px;">
            <h2 style="margin-top: 0;">📚 Public Features</h2>
            
            <div class="flm-shortcode-box" style="background: #f9f9f9; padding: 15px; margin-bottom: 20px; border-left: 4px solid #f59e0b;">
                <h3 style="margin-top: 0;">[farsi_lesson_list]</h3>
                <input type="text" value='[farsi_lesson_list]' readonly style="width: 100%; padding: 10px; font-family: monospace; font-size: 14px; background: #fff; border: 1px solid #000; margin-bottom: 10px;" onclick="this.select();">
                <p style="margin: 10px 0 5px 0;"><strong>Purpose:</strong> Display all published lessons from all instructors</p>
                <p style="margin: 5px 0;"><strong>Features:</strong></p>
                <ul style="margin-top: 5px; margin-left: 20px;">
                    <li>Real-time search filter</li>
                    <li>Shows title, instructor, notes</li>
                    <li>View lesson button for everyone</li>
                    <li>Edit/delete buttons (permission-based)</li>
                </ul>
                <p style="margin: 5px 0;"><strong>Required Page:</strong> Create page at <code>/lessons/</code></p>
                <p style="margin: 5px 0;"><strong>Access:</strong> Everyone can view, permissions apply for editing</p>
            </div>
            
            <div class="flm-shortcode-box" style="background: #f9f9f9; padding: 15px; border-left: 4px solid #f59e0b;">
                <h3 style="margin-top: 0;">[farsi_student_form]</h3>
                <input type="text" value='[farsi_student_form]' readonly style="width: 100%; padding: 10px; font-family: monospace; font-size: 14px; background: #fff; border: 1px solid #000; margin-bottom: 10px;" onclick="this.select();">
                <p style="margin: 10px 0 5px 0;"><strong>Purpose:</strong> Student submission form for completed assignments</p>
                <p style="margin: 5px 0;"><strong>Features:</strong></p>
                <ul style="margin-top: 5px; margin-left: 20px;">
                    <li>Student and mentor email fields</li>
                    <li>Subject/lesson name</li>
                    <li>Security code validation (real-time)</li>
                    <li>Multiple file uploads (PDF/Word)</li>
                    <li>Email notifications to mentor</li>
                    <li>Submit button disabled until valid code entered</li>
                </ul>
                <p style="margin: 5px 0;"><strong>Required Page:</strong> Create page at <code>/submit-work/</code></p>
                <p style="margin: 5px 0;"><strong>Access:</strong> Public (protected by security code)</p>
                <p style="margin: 5px 0; color: #dc3545;"><strong>⚠️ Important:</strong> Create security codes in "Security Codes" page before sharing this form</p>
            </div>
        </div>
        
        <!-- User Roles -->
        <div class="flm-settings-section" style="background: #fff; padding: 20px; border: 1px solid #ccc;">
            <h2 style="margin-top: 0;">👥 User Roles & Permissions</h2>
            <table class="wp-list-table widefat fixed striped">
                <thead>
                    <tr>
                        <th style="width: 20%;">Role</th>
                        <th style="width: 80%;">Capabilities</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td><strong>Administrator</strong></td>
                        <td>
                            Full control - manage everything<br>
                            • Access wp-admin<br>
                            • Create/edit/delete all lessons<br>
                            • Manage security codes<br>
                            • View submission log<br>
                            • Manage all users
                        </td>
                    </tr>
                    <tr>
                        <td><strong>Team Leader</strong></td>
                        <td>
                            Manage all lessons and instructors<br>
                            • Create/edit/delete all lessons<br>
                            • View all submissions<br>
                            • Edit all notes
                        </td>
                    </tr>
                    <tr>
                        <td><strong>Chairperson</strong></td>
                        <td>
                            Review and approve materials<br>
                            • Edit all lessons<br>
                            • View all submissions<br>
                            • Cannot delete others' lessons
                        </td>
                    </tr>
                    <tr>
                        <td><strong>Instructor</strong></td>
                        <td>
                            Add and manage own materials<br>
                            • Create lessons<br>
                            • Edit/delete only their own lessons<br>
                            • View all lessons<br>
                            • Receive submission notifications
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
    <?php
}
