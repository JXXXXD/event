<?php
/**
 * Meta Boxes
 */

if (!defined('ABSPATH')) exit;

add_action('add_meta_boxes', 'flm_add_meta_boxes');
function flm_add_meta_boxes() {
    add_meta_box('flm_lesson_files', 'Lesson Files', 'flm_render_lesson_files_metabox', 'farsi_lesson', 'normal', 'high');
    add_meta_box('flm_lesson_notes', 'Notes', 'flm_render_lesson_notes_metabox', 'farsi_lesson', 'side', 'default');
    add_meta_box('flm_lesson_shortcode', 'Shortcode & Links', 'flm_render_shortcode_metabox', 'farsi_lesson', 'side', 'high');
    add_meta_box('flm_submission_details', 'Submission Details', 'flm_render_submission_metabox', 'farsi_submission', 'normal', 'high');
}

function flm_render_lesson_files_metabox($post) {
    wp_nonce_field('flm_save_lesson', 'flm_lesson_nonce');
    
    $student_file = get_post_meta($post->ID, '_flm_student_file', true);
    $teacher_file = get_post_meta($post->ID, '_flm_teacher_file', true);
    $audio_file = get_post_meta($post->ID, '_flm_audio_file', true);
    ?>
    
    <div class="flm-field">
        <label>Student File (PDF/Word)</label>
        <div class="flm-field-row">
            <input type="hidden" name="flm_student_file" id="flm_student_file" value="<?php echo esc_attr($student_file); ?>">
            <input type="text" id="flm_student_file_url" value="<?php echo $student_file ? esc_url(wp_get_attachment_url($student_file)) : ''; ?>" readonly placeholder="No file selected">
            <button type="button" class="button flm-upload" data-target="student_file">Select</button>
            <button type="button" class="button flm-remove" data-target="student_file">Remove</button>
        </div>
        <p class="description">The file students will download to complete.</p>
    </div>
    
    <div class="flm-field">
        <label>Teacher File / Answer Key (PDF/Word)</label>
        <div class="flm-field-row">
            <input type="hidden" name="flm_teacher_file" id="flm_teacher_file" value="<?php echo esc_attr($teacher_file); ?>">
            <input type="text" id="flm_teacher_file_url" value="<?php echo $teacher_file ? esc_url(wp_get_attachment_url($teacher_file)) : ''; ?>" readonly placeholder="No file selected">
            <button type="button" class="button flm-upload" data-target="teacher_file">Select</button>
            <button type="button" class="button flm-remove" data-target="teacher_file">Remove</button>
        </div>
        <p class="description">The answer key sent to students after submission.</p>
    </div>
    
    <div class="flm-field">
        <label>Audio File (Optional - MP3)</label>
        <div class="flm-field-row">
            <input type="hidden" name="flm_audio_file" id="flm_audio_file" value="<?php echo esc_attr($audio_file); ?>">
            <input type="text" id="flm_audio_file_url" value="<?php echo $audio_file ? esc_url(wp_get_attachment_url($audio_file)) : ''; ?>" readonly placeholder="No file selected">
            <button type="button" class="button flm-upload" data-target="audio_file">Select</button>
            <button type="button" class="button flm-remove" data-target="audio_file">Remove</button>
        </div>
        <p class="description">Optional audio accompaniment.</p>
    </div>
    <?php
}

function flm_render_lesson_notes_metabox($post) {
    $notes = get_post_meta($post->ID, '_flm_notes', true);
    
    // Only Administrators can edit notes here. 
    // Everyone else must use the List Dashboard.
    $can_edit_here = current_user_can('administrator');
    
    if ($can_edit_here) {
        ?>
        <textarea name="flm_notes" rows="5" style="width:100%;" placeholder="Add notes about this lesson..."><?php echo esc_textarea($notes); ?></textarea>
        <p class="description">Internal notes for admin reference.</p>
        <?php
    } else {
        ?>
        <div style="background: #f9f9f9; padding: 10px; border: 1px solid #ddd; border-radius: 4px; min-height: 40px; color: #555; font-size: 13px;">
            <?php echo $notes ? nl2br(esc_html($notes)) : '<em>No notes added.</em>'; ?>
        </div>
        <p class="description">
            <span class="dashicons dashicons-lock" style="font-size: 16px; width: 16px; height: 16px; vertical-align: text-bottom;"></span> 
            Read-only. Please edit notes in the <a href="<?php echo admin_url('admin.php?page=farsi-learning-manager'); ?>">Lesson List</a>.
        </p>
        <?php
    }
}

function flm_render_shortcode_metabox($post) {
    if ($post->post_status === 'publish') {
        echo '<div style="margin-bottom:15px;">';
        echo '<strong>Shortcode:</strong><br>';
        echo '<input type="text" value="[farsi_student_form id=&quot;' . $post->ID . '&quot;]" readonly style="width:100%;margin-top:5px;" onclick="this.select();">';
        echo '</div>';
        
        echo '<div style="margin-bottom:15px;">';
        echo '<strong>Direct Link:</strong><br>';
        echo '<input type="text" value="' . get_permalink($post->ID) . '" readonly style="width:100%;margin-top:5px;" onclick="this.select();">';
        echo '</div>';
    } else {
        echo '<p>Publish this lesson to get the shortcode and link.</p>';
    }
}

function flm_render_submission_metabox($post) {
    $fields = array(
        'Student Name' => get_post_meta($post->ID, '_flm_student_name', true),
        'Student Email' => get_post_meta($post->ID, '_flm_student_email', true),
        'Mentor Email' => get_post_meta($post->ID, '_flm_mentor_email', true),
        'Submission Date' => get_post_meta($post->ID, '_flm_submission_date', true),
        'Notes' => get_post_meta($post->ID, '_flm_notes', true),
    );
    
    $lesson_id = get_post_meta($post->ID, '_flm_lesson_id', true);
    $file = get_post_meta($post->ID, '_flm_submitted_file', true);
    
    echo '<table class="form-table">';
    foreach ($fields as $label => $value) {
        echo '<tr><th>' . esc_html($label) . '</th><td>' . esc_html($value) . '</td></tr>';
    }
    echo '<tr><th>Lesson</th><td>' . ($lesson_id ? esc_html(get_the_title($lesson_id)) : 'N/A') . '</td></tr>';
    if ($file) {
        echo '<tr><th>File</th><td><a href="' . esc_url($file) . '" class="button" target="_blank">Download Submission</a></td></tr>';
    }
    echo '</table>';
}

add_action('save_post_farsi_lesson', 'flm_save_lesson_meta');
function flm_save_lesson_meta($post_id) {
    if (!isset($_POST['flm_lesson_nonce']) || !wp_verify_nonce($_POST['flm_lesson_nonce'], 'flm_save_lesson')) {
        return;
    }
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
        return;
    }
    if (!current_user_can('edit_post', $post_id)) {
        return;
    }
    
    $fields = array('student_file', 'teacher_file', 'audio_file');
    foreach ($fields as $field) {
        if (isset($_POST['flm_' . $field])) {
            update_post_meta($post_id, '_flm_' . $field, absint($_POST['flm_' . $field]));
        }
    }
    
    // Only save notes from this screen if Administrator
    // Instructors must use the AJAX List save method
    if (isset($_POST['flm_notes']) && current_user_can('administrator')) {
        update_post_meta($post_id, '_flm_notes', sanitize_textarea_field($_POST['flm_notes']));
    }
}